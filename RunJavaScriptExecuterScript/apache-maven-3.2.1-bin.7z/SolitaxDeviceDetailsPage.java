/**
 * 
 */
package automation.framework.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/**
 * @author Mandar_Tankasale
 * Device Details page operations for solitax
 */
public class SolitaxDeviceDetailsPage {
	WebDriver fusionDriver;
	@FindBy(css="div.hachicon hachicon-wrench fusion-link-bar-icon")
	private WebElement maintenanceLinkBarIcon;
	protected SolitaxDeviceDetailsPage(WebDriver fusionDriver) {
		this.fusionDriver = fusionDriver;
	}
	public SolitaxMaintenancePage ClickOnMaintenanceLinkIsDisplayed(){		
		Assert.assertNotNull(maintenanceLinkBarIcon, "Maintenance link element is null");
		maintenanceLinkBarIcon.click();
		return PageFactory.initElements(fusionDriver, SolitaxMaintenancePage.class);
	}
	
	public SolitaxCleaningFirstPage clickOnCleaningBanner() {
		boolean isCleaningWorkflowTriggered=false;
		List <WebElement> workFlowWarningBanners=new ArrayList<WebElement>();
		workFlowWarningBanners=fusionDriver.findElements(By.cssSelector("div.fusion-standard-table-div>span"));
		for (WebElement webElement : workFlowWarningBanners) {
			if (webElement.getText().contains("Cleaning")) {
				isCleaningWorkflowTriggered=true;
				webElement.click();
			}
			
		}
		Assert.assertTrue(isCleaningWorkflowTriggered, "Cleaning workflow is not triggered");
		return PageFactory.initElements(fusionDriver, SolitaxCleaningFirstPage.class);
	}
	
	
}
 