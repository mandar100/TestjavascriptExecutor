/**
 * 
 */
package automation.commonfunctions;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mandar_Tankasale
 *
 */
public class Tenant {
	String tenantId,tenantEmail,tenantPassword, teantGatewayId;
	 List<String>tenantSensorList= new ArrayList<String>();
	protected String getTenantId() {
		return tenantId;
	}
	protected void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	@Override
	public String toString() {
		return "Tenant [tenantId=" + tenantId + ", tenantEmail=" + tenantEmail
				+ ", tenantPassword=" + tenantPassword + ", teantGatewayId="
				+ teantGatewayId + ", tenantSensorList=" + tenantSensorList
				+ "]";
	}
	protected String getTenantEmail() {
		return tenantEmail;
	}
	protected void setTenantEmail(String tenantEmail) {
		this.tenantEmail = tenantEmail;
	}
	protected String getTenantPassword() {
		return tenantPassword;
	}
	protected void setTenantPassword(String tenantPassword) {
		this.tenantPassword = tenantPassword;
	}
	protected String getTeantGatewayId() {
		return teantGatewayId;
	}
	protected void setTeantGatewayId(String teantGatewayId) {
		this.teantGatewayId = teantGatewayId;
	}
	protected List<String> getTenantSensorList() {
		return tenantSensorList;
	}
	 

}
