/**
 * 
 */
package automation.framework.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;

/**
 * @author Shubhangi_Pote
 *
 */
public class SolitaxCleaningCarouselPage {

	WebDriver driver;
	public SolitaxCleaningCarouselPage()
	{
		driver = BrowserHelper.driver;
	}
	public void verifyCarouselPageForSolitaxCleaning(String sensorId){
		String url = driver.getCurrentUrl();
		String[] slide1 = {"soft, wet cloth","cleaning agent","water to rinse the sensor"};
		List<String> ls = new ArrayList();
		for(int i=0;i<slide1.length;i++){
			ls.add(slide1[i]);
		}
		Assert.assertEquals(url.contains("Step2"),true,"comparing URLs");
		List<String> list = new ArrayList();
		int size = driver.findElements(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/div/ul/li")).size();
		
		for(int i=1;i<=size;i++){
			System.out.println(driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/div/ul/li["+i+"]")).getText());
			list.add(driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/div/ul/li["+i+"]")).getText());
		}
		Assert.assertEquals(list,ls,"comparing slide1");
		String expSlide2 = "Remove the sensor from the process. Clean the exterior of the sensor with a soft, wet cloth.";
		String actSlide2 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[2]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide2,actSlide2,"comparing slide2");
		String expSlide3 = "Clean the measuring window with the cleaning agent.";
		String actSlide3 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[3]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide3,actSlide3,"comparing slide3");
		boolean backChevron = driver.findElement(By.xpath(".//*[@id='navBar']/div/a/div")).isEnabled();
		Assert.assertEquals(backChevron,true,"Checking back chevron");
		boolean continueBtn = driver.findElement(By.cssSelector("button[id='continueButton']")).isEnabled();
		Assert.assertEquals(continueBtn,true,"Checking Continue button");
		boolean cancelBtn = driver.findElement(By.cssSelector("button[id='cancelButton']")).isEnabled();
		Assert.assertEquals(cancelBtn,true,"Checking Cancel button");
		driver.findElement(By.cssSelector("button[id='continueButton']")).click();
	}
}
