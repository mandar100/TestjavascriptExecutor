/**
 * 
 */
package automation.framework.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;

/**
 * @author Shubhangi_Pote
 *
 */
public class SolitaxWiperActivation {
	
	WebDriver driver;
	public SolitaxWiperActivation()
	{
		driver = BrowserHelper.driver;
	}
	
	public void wiperActivation(String sensorId) throws Exception{
		WebDriverWait wait = new WebDriverWait(driver,30);
		String command = "FusionDeviceEmulator.exe -m s -s "+sensorId+" --stt sequence_id=trigger_wipe success=true";
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("button[id='start']"))));
		verifyWiperActivationPageUIElements();	
		CommonFunctions.takeSnap(driver, "./one.jpg");
		driver.findElement(By.cssSelector("button[id='start']")).click();	
		CommonFunctions.executeCommand(command);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("button[id='continueButton']"))));
		boolean continueBtn = driver.findElement(By.cssSelector("button[id='continueButton']")).isEnabled();
		Assert.assertEquals(continueBtn,true,"Checking Continue button is enabled");
	}	
	
	public void verifyTimeOutAndErrorPopup(String sensorId) throws Exception{
		WebDriverWait wait = new WebDriverWait(driver,40);
		String expText = "The operation failed.";
		String command = "FusionDeviceEmulator.exe -m s -s "+sensorId+" --stt sequence_id=trigger_wipe success=false";
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("button[id='start']"))));
		driver.findElement(By.cssSelector("button[id='start']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[id='keep-waiting']")));
		driver.findElement(By.cssSelector("button[id='keep-waiting']")).click();
		CommonFunctions.executeCommand(command);
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[id='retry-wipe']")));
		String actText = driver.findElement(By.xpath(".//*[@id='wiper-failed-modal']/div/div/div[2]/p")).getText();
		Assert.assertEquals(actText,expText,"Checking text on popup");
		driver.findElement(By.cssSelector("button[id='wipe-cancel']")).click();
	}
	
	public void verifyWiperActivationPageUIElements(){
		String expText = "After cleaning the measuring window, activate the wiper multiple times.";
		Assert.assertEquals(driver.getTitle(), "Wiper activation - Fusion", "comparing page title");
		boolean backChevron = driver.findElement(By.xpath(".//*[@id='navBar']/div/a/div")).isEnabled();
		Assert.assertEquals(backChevron,true,"Checking back chevron");
		boolean continueBtn = driver.findElement(By.cssSelector("button[id='continueButton']")).isEnabled();
		Assert.assertEquals(continueBtn,false,"Checking Continue button is disabled");
		boolean cancelBtn = driver.findElement(By.cssSelector("button[id='cancelButton']")).isEnabled();
		Assert.assertEquals(cancelBtn,true,"Checking Cancel button");
		boolean startBtn = driver.findElement(By.cssSelector("button[id='start']")).isEnabled();
		Assert.assertEquals(cancelBtn,true,"Checking start button");
		String text = driver.findElement(By.xpath("//div[@class='text-center']/div[3]")).getText();
		Assert.assertEquals(text,expText,"Checking text on page");
	}
}
