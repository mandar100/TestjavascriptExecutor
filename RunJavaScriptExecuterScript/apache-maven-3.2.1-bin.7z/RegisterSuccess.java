import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterSuccess {
	final WebDriver driver;
	@FindBy(xpath="/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p/font/b")
	private WebElement verifyTextMessage;
	@FindBy(xpath="/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[2]/font")
	private WebElement verifyConfirmationMessage;
	@FindBy(xpath="/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[3]/td/p[3]/a/font/b")
	private WebElement verifyNoteText;
	public RegisterSuccess(WebDriver driver)
	{
		this.driver=driver;
	}
	public void isRegistretSuccessful(String firstName, String lastName, String userName) 
	{
		System.out.println("Test Messages: "+verifyTextMessage.getText());
		System.out.println("Confirmation Messages is : "+verifyConfirmationMessage.getText());
		System.out.println("Note Messages is : "+verifyNoteText.getText());
		if (verifyTextMessage.getText().equals("Dear "+firstName+" "+lastName+",")&&verifyConfirmationMessage.getText().equals("Thank you for registering. You may now sign-in using the user name and password you've just entered.")&&verifyNoteText.getText().equals("Note: Your user name is "+userName+".")) 
		{
			System.out.println("User is Registered successfully....");
		}
		else
		{
			System.out.println("User Registation is  unsuccessful....");
		}
	}

}
