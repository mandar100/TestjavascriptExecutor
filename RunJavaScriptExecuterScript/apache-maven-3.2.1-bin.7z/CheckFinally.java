package com.secureBrowse;

public class CheckFinally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		System.out.println("Value of i is: "+getValueOfFinally());

	}
	
	@SuppressWarnings("finally")
	private static int getValueOfFinally() {
		// TODO Auto-generated method stub
		int i=10;
		try
		{
			return i/2;
		}
		catch(Exception e)
		{
			return i;
		}
		finally
		{
			 i=100;
			return i;
		}
	}


}
