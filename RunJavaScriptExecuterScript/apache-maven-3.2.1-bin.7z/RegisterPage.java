import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {
private final WebDriver driver;
@FindBy(name="firstName")
private WebElement firstNameEdit;
@FindBy(name="lastName")
private WebElement lastNameEdit;
@FindBy(name="phone")
private WebElement phoneEdit;
@FindBy(id="userName")
private WebElement userNameEdit;
@FindBy(name="address1")
private WebElement address1Edit;
@FindBy(name="address2")
private WebElement address2Edit;
@FindBy(name="city")
private WebElement cityEdit;
@FindBy(name="state")
private WebElement stateEdit;
@FindBy(name="postalCode")
private WebElement postalCodeEdit;
@FindBy(name="country")
private WebElement countryEdit;
@FindBy(name="email")
private WebElement emailEdit;
@FindBy(name="password")
private WebElement passwordEdit;
@FindBy(name="confirmPassword")
private WebElement confirmPasswordEdit;
@FindBy(name="register")
private WebElement registerEdit;
public RegisterPage(WebDriver driver)
{
	this.driver=driver;
		
}
public void enterFirstName(String firstName)
{
	firstNameEdit.clear();
	firstNameEdit.sendKeys(firstName);
}
public void enterLastName(String lastName)
{
	lastNameEdit.clear();
	lastNameEdit.sendKeys(lastName);
}
public void enterPhone(String phone)
{
	phoneEdit.clear();
	phoneEdit.sendKeys(phone);
}
public void enterUserName(String userName)
{
	userNameEdit.clear();
	userNameEdit.sendKeys(userName);
}
public void enterAddress1(String address1)
{
	address1Edit.clear();
	address1Edit.sendKeys(address1);
}
public void enterAddress2(String address2)
{
	address2Edit.clear();
	address2Edit.sendKeys(address2);
}
public void enterCity(String city)
{
	cityEdit.clear();
	cityEdit.sendKeys(city);
}
public void enterState(String state)
{
	stateEdit.clear();
	stateEdit.sendKeys(state);
}
public void enterPostalCode(String postalCode)
{
	postalCodeEdit.clear();
	postalCodeEdit.sendKeys(postalCode);
}
public void enterCountry(String country)
{
	countryEdit.sendKeys(country);
}
public void enterEmail(String email)
{
	emailEdit.clear();
	emailEdit.sendKeys(email);
}
public void enterPassword(String password)
{
	passwordEdit.clear();
	passwordEdit.sendKeys(password);
}
public void enterConfirmPassword(String confirmPassword)
{
	confirmPasswordEdit.clear();
	confirmPasswordEdit.sendKeys(confirmPassword);
}

public void clickRegisterButton() {
	// TODO Auto-generated method stub
	registerEdit.click();
}
public RegisterSuccess register(String firstName, String lastName, String phone, String userName, String address1, String address2, String city, String state, String postalCode, String country, String email, String password) {
	// TODO Auto-generated method stub
	enterFirstName(firstName);
	enterLastName(lastName);
	enterPhone(phone);
	enterEmail(email);
	enterAddress1(address1);
	enterAddress2(address2);
	enterCity(city);
	enterState(state);
	enterPostalCode(postalCode);
	enterCountry(country);
	enterUserName(userName);
	enterPassword(password);
	enterConfirmPassword(password);
	clickRegisterButton();
	return PageFactory.initElements(driver, RegisterSuccess.class);	

}
}
