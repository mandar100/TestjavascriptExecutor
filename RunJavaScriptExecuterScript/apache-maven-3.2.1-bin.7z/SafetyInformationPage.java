/**
 * 
 */
package automation.framework.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

/**
 * Constructor of SafetyInformationPage
 * @author Shubhangi_Pote
 *
 */
public class SafetyInformationPage {
	
	WebDriver driver;	
		
	By popup = By.xpath(".//*[@id='cautionModal']/div");
	By cautionPage1Text = By.xpath(".//*[@id='carousel-slides']/div[1]/div[1]/div/div[2]/p");
	By cautionPage2Text = By.xpath(".//*[@id='carousel-slides']/div[1]/div[2]/div/div[2]/p");
	By nextArrow = By.xpath(".//*[@id='customNext']/span");
	By prevArrow = By.xpath(".//*[@id='customPrev']/span");
	By header = By.xpath(".//*[@id='cautionModal']/div/div[2]/div[1]/div[2]/span");
	By closePopup = By.xpath(".//*[@id='cautionModal']/div/div[1]/span");
	By pagingDots = By.className("carousel-indicators"); 
	
	private String expectedCautionPage1Text = "Biological hazard. Only qualified personnel must conduct the tasks described in this procedure.";
	private String expectedCautionPage2Text = "Chemical exposure hazard. Obey laboratory safety procedures and wear all of the personal protective equipment appropriate to the chemicals that are handled. Refer to the current safety data sheets (MSDS/SDS) for safety protocols.";
	private String expectedPopupHeader = "Caution";
	
	private String mismatchingCautionPage1Text = "Mismatching caution page1 text" ;
	private String mismatchingCautionPage2Text = "Mismatching caution page2 text" ;
	private String mismatchingPopupHeader = "Mismatching popup header" ;
	
	private String popupDoesNotClose = "Popup does not close on click on close button"; 
	private String MismatchingDotsCount = "Mismatching dots count on popup"; 
		
	/**
	 * Constructor of page
	 * @param driver = instance of web driver
	 */
	public SafetyInformationPage(WebDriver driver){
		this.driver = driver;		
	}
	
	/**
	 * Verifies popup header comes 
	 * 
	 */
	public void checkPopupHeader(){
		String actualPageHeader = driver.findElement(header).getText();
		Assert.assertEquals(actualPageHeader, expectedPopupHeader,mismatchingPopupHeader);
	}
	
	/**
	 * Verifies that the text of page1 is correct
	 * 
	 */
	public void validateTextOnCautionPage1(){
		String actualCautionPage1Text = driver.findElement(cautionPage1Text).getText();
		Assert.assertEquals(actualCautionPage1Text,expectedCautionPage1Text,mismatchingCautionPage1Text);
	}
	
	/**
	 * Verifies that the text of page2 is correct
	 * 
	 */
	public void validateTextOnCautionPage2(){
		String actualCautionPage2Text = driver.findElement(cautionPage2Text).getText();
		Assert.assertEquals(actualCautionPage2Text,expectedCautionPage2Text,mismatchingCautionPage2Text);
	}
	
	/**
	 * Verify that dots of paging working properly
	 */
	public void clickOnPagingDots(){
		List<WebElement> links= driver.findElements(pagingDots);
		Assert.assertEquals(2, links.size(),MismatchingDotsCount);
		
		links.get(0).click();
		validateTextOnCautionPage1();
		
		links.get(1).click();
		validateTextOnCautionPage2();
	}
	
	/**
	 * Verifies that the popup does not appear once closed it
	 * @return false since the popup closed 
	 */
	public boolean closeThePopup(){
		driver.findElement(closePopup).clear();
		boolean isPopupPresent = (driver.findElements(popup).size()==1);
		Assert.assertFalse(isPopupPresent,popupDoesNotClose);
		return isPopupPresent;
	}
} 
