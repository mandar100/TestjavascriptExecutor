/**
 * 
 */
package automation.commonfunctions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Driver;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.management.loading.PrivateClassLoader;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.omg.PortableServer.THREAD_POLICY_ID;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.Table.Cell;

/**
 * @author Nilesh_Dharmadhikari
 * @author Shubhangi_Pote
 * 
 */
public class CommonFunctions {

	public static boolean isHoldSetForWorkflow = false;
	public static String browser;
	public static String app_url;
	public static String WorkflowNameFromSensorInputData;
	public static String SensorIdFromSensorInputData;
	public static String SensorNameFromSensorInputData;
	public static String TenantIdFromSensorInputData;

	public static void executeCommand(String cmd) throws Exception {
		File currentDirFile = new File(".");
		System.out.println("executing emulator command");
		String dir = currentDirFile.getAbsolutePath().replace(".",
				"Utils\\FusionDeviceEmulatorUtility\\");
		Runtime rt = Runtime.getRuntime();
		Process proc = rt.exec("cmd /c start cmd.exe /K \"cd " + dir + "&& "
				+ cmd + "&& exit");
	}
	
	public static void takeSnap(WebDriver driver, String filePath)
			throws Exception {
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(filePath);
		FileUtils.copyFile(srcFile, DestFile);
	}
	
	/*
	 * Method - getWorkflowSpecificDataFromSensorDetailsRecord
	 * Desc - reads SensorDetailsRecord for specific workflow
	 * Parameter - hachLoginInfoData , workflow Name
	 * */
	public static void getWorkflowSpecificDataFromSensorDetailsRecord(String hachSensorDataFileName, String workflowName){
		Map<String, SensorDetailsRecord> sensorData=CommonFunctions.readSensorInputDataFile(hachSensorDataFileName);
		WorkflowNameFromSensorInputData = sensorData.get(workflowName).getWorkflowName();
		SensorIdFromSensorInputData = sensorData.get(workflowName).getSensorId();
		SensorNameFromSensorInputData = sensorData.get(workflowName).getSensorName();
		TenantIdFromSensorInputData = sensorData.get(workflowName).getTenantId();
	}

	public static void readConfiPropertiesFile(String configfilePath) {
		Properties prop = new Properties();
		InputStream input = null;

		try {

			input = new FileInputStream(configfilePath);

			// load a properties file
			prop.load(input);

			// get the property value and print it out
			app_url = prop.getProperty("app_url");
			browser = prop.getProperty("browser");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	
	public static void startWorkflow(WebDriver driver, String notificationName,
			String workflowName, String pageName, String sensorId) {
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		//String xpath = "//a[starts-with(@href, '/SolitaxMaintenance/Index')]"; //"//div[contains(text(),'" + notificationName + "'";		
		String xpath = "//div[contains(text(),'" + notificationName + "')]";
		boolean isElementPresent = BrowserHelper.isElementPresent(
				By.xpath(xpath), "Notification Bar");
		
		if (isElementPresent) {
			WebElement notificationEle = driver.findElement(By.xpath(xpath));
			BrowserHelper.clickOnElement(notificationEle, "Notification bar",
					pageName);
		} else {
			//WebElement ele = driver.findElement(By.xpath("//div[contains(text(),'Maintenance')]"));//("//a[starts-with(@href, '/SolitaxMaintenance/Index')]"));
			// Click on Maintenance link
			
			BrowserHelper.clickOnElement(driver.findElement(By.xpath("//div[text()='Maintenance']")),
										"Maintenance Link", pageName);
			// Click on Trigger 
			clickOnTriggerNowButton(driver, workflowName, "Trigger Maintenance");
			// Wait to navigate to device details page
			/*try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			WebElement notificationEle = driver.findElement(By.xpath(xpath));
			wait.until(ExpectedConditions.elementToBeClickable(notificationEle));
			BrowserHelper.clickOnElement(notificationEle, "Notification bar",
					pageName);			
		}
	}

	/**
	 * It will click on element based on 'ele' reference.
	 * 
	 * @param driver
	 * @param workflowName
	 * @param pageName
	 */
	private static void clickOnTriggerNowButton(WebDriver driver,
			String workflowName, String pageName) {
		try {
			WebElement ele = driver.findElement(By
					.xpath("//span[contains(text(),'" + workflowName
							+ "')]/../following-sibling::div/span"));
			BrowserHelper.clickOnElement(ele, "Trigger Now", pageName);

		} catch (NoSuchElementException ex) {
			System.out
					.println("Element not found exception:" + ex.getMessage());
			Assert.assertFalse(ex.getMessage(), true);
		} catch (Exception e) {
			System.out.println("Exception in click method - " + e.getMessage());
			Assert.assertFalse(e.getMessage(), true);
		}
	}

	/**
	 * @author Mandar_Tankasale Function returns first tenant data from .json
	 *         file.
	 */
	public static Tenant getFirstTenantDataFromJson() {

		JSONParser parser = new JSONParser();

		try {

			JSONObject jsonObject = (JSONObject) parser
					.parse(new InputStreamReader(new FileInputStream(
							"D:\\Team2_Sensor\\Tools\\practice_data.json")));
			Tenant hachTenant = new Tenant();
			JSONArray values = (JSONArray) jsonObject.get("Tenants");
			System.out.println(values.size());
			Iterator<JSONObject> iterator = values.iterator();
			while (iterator.hasNext()) {
				JSONObject idObj = (JSONObject) iterator.next();
				hachTenant.tenantId = (String) idObj.get("Id");
				// System.out.println(tenantId);
				JSONArray valuesgatewayList = (JSONArray) idObj.get("Gateways");
				Iterator<JSONObject> iteratorGw = valuesgatewayList.iterator();
				JSONArray sensorList;
				while (iteratorGw.hasNext()) {
					JSONObject gwidObj = (JSONObject) iteratorGw.next();
					hachTenant.teantGatewayId = (String) gwidObj.get("Id");
					String Gw_name = (String) gwidObj.get("Name");
					sensorList = (JSONArray) gwidObj.get("Sensors");
					Iterator<JSONObject> sensors = sensorList.iterator();
					while (sensors.hasNext()) {
						JSONObject jsonObject2 = (JSONObject) sensors.next();
						hachTenant.tenantSensorList.add((String) jsonObject2
								.get("Id"));

					}
					System.out.println(hachTenant.toString());

					// System.out.println(Gw_id+" \n Name of gateway is: "+Gw_name);
				}
			}

			return hachTenant;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * @author Shubhangi_Pote This method read the data from excel sheet and
	 *         return map contains userName, Password
	 * 
	 */
	@SuppressWarnings("resource")
	public static Map<String, LoginDetailsRecord> readHachDataFile(
			String hachDataFileName) {
		XSSFWorkbook dataWorkbook = null;
		Map<String, LoginDetailsRecord> recordsMap = new<String, LoginDetailsRecord> HashMap();
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(hachDataFileName);
			if (hachDataFileName.endsWith("xlsx")) {
				dataWorkbook = new XSSFWorkbook(inputStream);
			} else {
				throw new IllegalArgumentException(
						"The specified file is not Excel file(.xlsx)");
			}

			XSSFSheet hachUserCrentialsSheet = dataWorkbook.getSheetAt(0);
			for (int count = 1; count <= hachUserCrentialsSheet.getLastRowNum(); count++) {
				LoginDetailsRecord record = new LoginDetailsRecord();
				String userRole = hachUserCrentialsSheet.getRow(count)
						.getCell(0).getStringCellValue();
				String userName = hachUserCrentialsSheet.getRow(count)
						.getCell(1).getStringCellValue();
				record.setUserName(userName);
				String Password = hachUserCrentialsSheet.getRow(count)
						.getCell(2).getStringCellValue();
				record.setPassword(Password);
				recordsMap.put(userRole, record);
			}

			dataWorkbook.close();
			inputStream.close();
			return recordsMap;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	@SuppressWarnings("resource")
	public static Map<String, SensorDetailsRecord> readSensorInputDataFile(
			String hachSensorDataFileName) {
		XSSFWorkbook dataWorkbook = null;
		Map<String, SensorDetailsRecord> recordsMap = new<String, SensorDetailsRecord> HashMap();
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(hachSensorDataFileName);
			if (hachSensorDataFileName.endsWith("xlsx")) {
				dataWorkbook = new XSSFWorkbook(inputStream);
			} else {
				throw new IllegalArgumentException(
						"The specified file is not Excel file(.xlsx)");
			}

			XSSFSheet hachSensorDataSheet = dataWorkbook.getSheetAt(0);
			for (int count = 1; count <= hachSensorDataSheet.getLastRowNum(); count++) {
				SensorDetailsRecord record = new SensorDetailsRecord();
				
				if(hachSensorDataSheet.getRow(count)
				.getCell(0)==null)
				{
					throw new IllegalArgumentException(
							"The specified file has blank workflow name");
				}
				else
				{		
					String workflowName = hachSensorDataSheet.getRow(count)
							.getCell(0).getStringCellValue();
					record.setWorkflowName(workflowName);
					if(hachSensorDataSheet.getRow(count)
							.getCell(1)==null)
					{
						throw new IllegalArgumentException(
								"The specified file has blank sensor id for at row"+count);
					}
					else
					{
						String sensorId  = hachSensorDataSheet.getRow(count)
								.getCell(1).getStringCellValue();
						record.setSensorId(sensorId);
					}
					if(hachSensorDataSheet.getRow(count)
							.getCell(2)==null)
					{
						record.setSensorName(null);
					}
					else
					{
						String sensorName = hachSensorDataSheet.getRow(count)
								.getCell(2).getStringCellValue();
						record.setSensorName(sensorName);
					}
					if(hachSensorDataSheet.getRow(count)
							.getCell(3)==null)
					{
						record.setTenantId(null);
					}
					else
					{
						String tenantId = hachSensorDataSheet.getRow(count)
								.getCell(3).getStringCellValue();
						record.setTenantId(tenantId);
					}					
					recordsMap.put(workflowName, record);
				}
			}

			dataWorkbook.close();
			inputStream.close();
			return recordsMap;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
