/**
 * This file verifies various functionalities of Solitax cleaning workflow page1
 */
package automation.framework.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;

/**
 * @author Shubhangi_Pote
 *
 */
public class SolitaxCleaningFirstPage {
	
	WebDriver driver;
	CommonFunctions cf;

	//Region - element identifiers 
	@FindBy(xpath=".//*[@id='cautionModal']/div")
	WebElement popup;	
	@FindBy(xpath = ".//*[@id='dvTitleHome']")
	WebElement pageHeaderText;
	@FindBy(xpath=".//*[@id='navBar']/div/a/div")
	WebElement backArrow;
	@FindBy(xpath=".//*[@id='HoldOutput']/div")
	WebElement outputHoldActivePanel;
	@FindBy(xpath="html/body/div[2]/a/div/div/div/span[2]")
	WebElement safetyInfoLink;
	@FindBy(xpath=".//*[@id='buttonGroup']/button[1]")
	WebElement holdBtn;
	@FindBy(xpath=".//*[@id='buttonGroup']/button[2]")
	WebElement activeBtn;
	@FindBy(id="cancelButton")
	WebElement cancelBtn;
	@FindBy(id="continueButton")
	WebElement continueBtn;	
	//EndRegion
	
	//Region - String Variables 
	private String expectedWFPage1Header = "Manual sensor cleaning";
	private String expectedWFPage2Title ="Manual sensor cleaning - Fusion";
	private String expectedDeviceDetailsPageTitle ="Sensor Details - Fusion";
	private String expectedBackgroundColorBlue ="#0098db";
	private String expectedBackgroundColorWhite ="#fff";
	
	
	private String mismatchingWFPage1Header = "Mismatching page header on page1";
	private String mismatchingWFPage2Title = "User is not navigated to workflow page 2";
	private String mismatchingSensorDetailsTitle = "User is not navigated to solitax device details page";
	private String missingBackArrowInHeader = "Back arrow is missing in header on page1";	
	private String missingHoldActivePanel = "Hold Active Panel is missing in header on page1";
	private String missingSafetyInformationLink = "Safety Information Link is missing in header on page1";	
	private String holdOptionNotSelected ="Hold option has not been selected";
	private String holdOptionSelected = "Hold option also got selected along with Active";
	private String activeOptionNotSelected ="Active option has not been selected";
	private String activeOptionSelected = "Active option also got selected along with Hold";
	private String popupDoesNotExist = "No safety information popup appeared";
	//EndRegion
	
	/**
	 * Constructor of page
	 * @param driver = instance of web driver
	 */
	public SolitaxCleaningFirstPage(){
		this.driver =BrowserHelper.driver;
		//This initElements method will create all WebElements
		PageFactory.initElements(this.driver, this);
	}
	
	/**
	 * Verifies Solitax Cleaning WF Page 1 header
	 */
	public void checkPageHeader(){
		By pageHeaderText = By.xpath(".//*[@id='dvTitleHome']");
		String expectedWFPage1Header = "Manual sensor cleaning";
		String mismatchingWFPage1Header = "Mismatching page header on page1";
		String pageHeader=driver.findElement(pageHeaderText).getText();
		Assert.assertEquals(pageHeader,expectedWFPage1Header,mismatchingWFPage1Header);
	}
	
	/**
	 * Verifies if back arrow present in header
	 * @return : true if back arrow present in header
	 */
	public Boolean isBackArrowPresentInHeader(){
		By backArrow = By.xpath(".//*[@id='navBar']/div/a/div");
		String missingBackArrowInHeader = "Back arrow is missing in header on page1";
		boolean isElementPresent = (driver.findElements(backArrow).size()==1);
		//Assert.assertTrue(isElementPresent,missingBackArrowInHeader);
		return isElementPresent;
	}
	
	/**
	 * Verifies user has been navigated to device details page if user clicks on back arrow
	 */
	public void clickOnBackArrowPresentInHeader(){;
		BrowserHelper.clickOnElement(backArrow, "", "");
		
		String pageTitle= BrowserHelper.getTitleOfPage();
		if(CommonFunctions.SensorNameFromSensorInputData!=null)
		{
			expectedDeviceDetailsPageTitle = CommonFunctions.SensorNameFromSensorInputData+" - SOLITAX sc - Fusion";
		}
		else
		{
			expectedDeviceDetailsPageTitle = "- SOLITAX sc - Fusion";
		} 
		
		try {
			if(pageTitle.contains("- SOLITAX sc"))
				Assert.assertTrue(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Verifies if Hold Active panel is present on page
	 * @return : true if Hold Active panel is present on page
	 */
	public boolean isHoldActivePanelIsPresent(){
	  boolean isElementPresent =(outputHoldActivePanel.isEnabled());
	  Assert.assertTrue(isElementPresent,missingHoldActivePanel);
	  return isElementPresent;
	}
	
	/**
	 * Verifies functionality of hold option
	 */
	public void selectHold(){
		BrowserHelper.clickOnElement(holdBtn, "hold button", "Page 1");		
		String holdBtnBackgroundColor = holdBtn.getText();
		String activeBtnBackgroundColor = activeBtn.getText();
		Assert.assertEquals(holdBtnBackgroundColor,expectedBackgroundColorBlue,holdOptionNotSelected);
		Assert.assertEquals(activeBtnBackgroundColor,expectedBackgroundColorWhite,activeOptionSelected);
	}
	
	/**
	 * Verifies functionality of active option
	 */
	public void selectActive(){
		BrowserHelper.clickOnElement(activeBtn, "Active button", "Page 1");
		//driver.findElement(activeBtn).click();
		String holdBtnBackgroundColor = holdBtn.getText();
		String activeBtnBackgroundColor = activeBtn.getText();
		Assert.assertEquals(activeBtnBackgroundColor,expectedBackgroundColorBlue,activeOptionSelected);
		Assert.assertEquals(holdBtnBackgroundColor,expectedBackgroundColorWhite,holdOptionNotSelected); 
		
	}
	
	/**
	 * Verifies if Safety information link is present
	 * @return : true if Safety information link is present
	 */
	public boolean isSafetyInformationLinkPresent(){
		boolean isElementPresent = (safetyInfoLink.isDisplayed());
		Assert.assertTrue(isElementPresent,missingSafetyInformationLink);
		return isElementPresent;
	}
	
	/**
	 * Verifies cancel button functionality
	 */
	public void cancelWFFromPage1(){
		BrowserHelper.clickOnElement(cancelBtn, "cancel button", "Page 1");
		
		Assert.assertEquals(BrowserHelper.getTitleOfPage(),expectedDeviceDetailsPageTitle,mismatchingSensorDetailsTitle );		
	}
	
	/**
	 * Verifies continue button functionality
	 */
	public void continueWFFromPage1(){
		BrowserHelper.clickOnElement(continueBtn, "Continue", "Page 1");
		
		Assert.assertEquals(BrowserHelper.getTitleOfPage(),expectedWFPage2Title,mismatchingWFPage2Title );
	}
	
	/**
	 * Verifies that safety information link functionality is working
	 * @return true if popup appears
	 */
	public boolean clickOnSafetyInformationLink(){				
		boolean isPopupPresent = (popup.isDisplayed());
		Assert.assertTrue(isPopupPresent,popupDoesNotExist);
		return isPopupPresent;		
	}
}

 