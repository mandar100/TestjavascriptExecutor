
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import jxl.*;
import jxl.read.biff.BiffException;
public class SearchFlight {
	/**
	 * @param args
	 */
	static Sheet loginSheet;
	static Sheet flightDetailsSheet;
    static Workbook workbook =null;
	public SearchFlight(String excelFilePath) throws BiffException, IOException {
		workbook=Workbook.getWorkbook(new File(excelFilePath));
		loginSheet=workbook.getSheet("Login");
		flightDetailsSheet=workbook.getSheet("FlightDetails");
		
	}
	public static int getflightDetailsSheetRowCount()
	{
		return flightDetailsSheet.getRows();
	}
	public static String FlightDetailsSheetReadCell(int column,int row)
    {
        return flightDetailsSheet.getCell(column,row).getContents();
    }
	public static String FlightDetailsSheetReadCell(String columnName)
    {
        return flightDetailsSheet.getCell(columnName).getContents();
    }
	public static String LoginSheetReadCell(int column,int row)
    {
        return loginSheet.getCell(column,row).getContents();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			WebDriver driver=new FirefoxDriver();
			driver.get("http://newtours.demoaut.com/index.php");
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			SearchFlight sf=new SearchFlight("Test_Data/BookFlight.xls");
			String username=sf.LoginSheetReadCell(0,1);
			String password=sf.LoginSheetReadCell(1,1);
			System.out.println("UserName is : "+username+"\n Password is : "+password);
			driver.findElement(By.name("userName")).sendKeys(username);
			driver.findElement(By.name("password")).sendKeys(password);
			driver.findElement(By.name("login")).click();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			for (int i = 1; i <=sf.getflightDetailsSheetRowCount(); i++) 
			{
				if (driver.getTitle().equals("Find a Flight: Mercury Tours:")) 
				{
					System.out.println("Login is successful....");
					enterDataFlightFinder(driver, sf, i);
					if (driver.getTitle().equals("Select a Flight: Mercury Tours")) 
					{
						driver.findElement(By.name("reserveFlights")).click();
						if (driver.getTitle().equals("Book a Flight: Mercury Tours")&&verifyBookFlightData(driver,sf.FlightDetailsSheetReadCell(2,i),sf.FlightDetailsSheetReadCell(5,i))) 
						{
							enterDataBookiFlight(driver,sf,i);
							if (driver.getTitle().equals("Flight Confirmation: Mercury Tours")) {
								File scrFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
								FileUtils.copyFile(scrFile, new File("Images\\"+i+"_flight_confirmation.jpg"));
								String departingLocation=sf.FlightDetailsSheetReadCell(2, i);
								String arrivingLocation=sf.FlightDetailsSheetReadCell(5, i);
								String serviceClass=sf.FlightDetailsSheetReadCell(8, i);
								String passengerCount=sf.FlightDetailsSheetReadCell(1, i);
								verifyFlightConfirmationDetails(driver,departingLocation,arrivingLocation,serviceClass,passengerCount);
								if (i==sf.getflightDetailsSheetRowCount()-1) {
									driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td[3]/a/img")).click();
									if (driver.getTitle().equals("Sign-on: Mercury Tours")) {
										System.out.println("Sign-On page is displayed");
										break;
										
									} else {
										System.out.println("Sign-On page is not displayed. Please Check with administrator");	
									}
								} else {
										driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[7]/td/table/tbody/tr/td/a/img")).click();
								}
							} else 
							{
									System.out.println("Flight Confirmation page is not displayed. please check again..");
							}
							
						} else 
						{
								System.out.println("Book a Flight Page Dada is not displayed. Please try once again");
						}
					} 
					else {
							System.out.println("Select Flight Page is not displayed. Please check Again");
					}
				}
				else
				{
					System.out.println("Login is not successful. Please try again...");
				}
				
			}
			
			 
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	private static void verifyFlightConfirmationDetails(WebDriver driver,String departingLoc,String arrivingLoc,String serviceClass,String passengerCount) 
	{
		if (driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[3]/td/font/b")).getText().equals(departingLoc+" to "+arrivingLoc)&&serviceClass.contains((CharSequence) driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[3]/td/font/br[2]")).getText())) {
			System.out.println("Departing Information is correct...");
		}
		else {
			System.out.println("Departing Information is not correct..");
		}
		// TODO Auto-generated method stub
		if (driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td/font/b")).getText().equals(arrivingLoc+" to "+departingLoc)&&serviceClass.startsWith(driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td/font/br[2]")).getText()) ) {
			System.out.println("Returning Information is correct.");
		} else {
			System.out.println("Returning Information is not correct.");
		}
		if (driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td/font")).getText().equals(passengerCount+" passenger")) {
			System.out.println("Passengers Information is correct");
		} else {
			System.out.println("Passengers Information is not correct");
		}
		
	}
	private static boolean verifyBookFlightData(WebDriver driver, String toLocation, String froLocation) {
		System.out.println("To location :"+toLocation+" Fro Location"+froLocation);
		// TODO Auto-generated method stub
		return driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td/table/tbody/tr/td/b/font")).getText().equals(toLocation+" to "+froLocation);
			 
		
	
		
	}
	private static void enterDataBookiFlight(WebDriver driver, SearchFlight sf,int rowNum) {
		// TODO Auto-generated method stub
		driver.findElement(By.name("passFirst0")).sendKeys(sf.FlightDetailsSheetReadCell(10,rowNum));
		driver.findElement(By.name("passLast0")).sendKeys(sf.FlightDetailsSheetReadCell(11,rowNum));
		driver.findElement(By.name("pass.0.meal")).sendKeys(sf.FlightDetailsSheetReadCell(12,rowNum));
		driver.findElement(By.name("creditCard")).sendKeys(sf.FlightDetailsSheetReadCell(13,rowNum));
		driver.findElement(By.name("creditnumber")).sendKeys(sf.FlightDetailsSheetReadCell(14,rowNum));
		driver.findElement(By.name("cc_exp_dt_mn")).sendKeys(sf.FlightDetailsSheetReadCell(15,rowNum));
		driver.findElement(By.name("cc_exp_dt_yr")).sendKeys(sf.FlightDetailsSheetReadCell(16,rowNum));
		driver.findElement(By.name("cc_frst_name")).sendKeys(sf.FlightDetailsSheetReadCell(17,rowNum));
		driver.findElement(By.name("cc_mid_name")).sendKeys(sf.FlightDetailsSheetReadCell(18,rowNum));
		driver.findElement(By.name("cc_last_name")).sendKeys(sf.FlightDetailsSheetReadCell(19,rowNum));
		driver.findElement(By.name("buyFlights")).click();
	}
	public static void enterDataFlightFinder(WebDriver driver, SearchFlight sf, int rowNum) {
		// TODO Auto-generated method stub
		selectRadioButtonOption(driver,"tripType",sf.FlightDetailsSheetReadCell(0,rowNum));
		driver.findElement(By.name("passCount")).sendKeys(sf.FlightDetailsSheetReadCell(1,rowNum));
		driver.findElement(By.name("fromPort")).sendKeys(sf.FlightDetailsSheetReadCell(2,rowNum));
		driver.findElement(By.name("fromMonth")).sendKeys(sf.FlightDetailsSheetReadCell(3,rowNum));
		driver.findElement(By.name("fromDay")).sendKeys(sf.FlightDetailsSheetReadCell(4,rowNum));
		driver.findElement(By.name("toPort")).sendKeys(sf.FlightDetailsSheetReadCell(5,rowNum));
		driver.findElement(By.name("toMonth")).sendKeys(sf.FlightDetailsSheetReadCell(6,rowNum));
		driver.findElement(By.name("toDay")).sendKeys(sf.FlightDetailsSheetReadCell(7,rowNum));
		selectRadioButtonOption(driver, "servClass", sf.FlightDetailsSheetReadCell(8,rowNum));				
		driver.findElement(By.name("airline")).sendKeys(sf.FlightDetailsSheetReadCell(9,rowNum));
		driver.findElement(By.name("findFlights")).click();
		
	}
	public static void selectRadioButtonOption(WebDriver driver, String locatorName, String value)
	{
		List<WebElement> radio = driver.findElements(By.name(locatorName));
		 for (WebElement element : radio)
		 {
		 if (element.getAttribute("value").equalsIgnoreCase(value)){
		 element.click();
		 }

		
	}

 }
}
