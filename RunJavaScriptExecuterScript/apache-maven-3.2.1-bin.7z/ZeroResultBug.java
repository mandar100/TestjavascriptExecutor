package testNG_Assignment;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class ZeroResultBug  {
	private WebDriver wd;
 @Test
  public void searchForZeroResultBug() {
	  wd.findElement(By.linkText("Search")).click();
		wd.findElement(By.linkText("Advanced Search")).click();
		wd.findElement(By.name("email2")).sendKeys("user@persistent.co.in");
		wd.findElement(By.id("Search")).click();
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		if (wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/span")).getText().equals("Zarro Boogs found.")) {
			System.out.println("Zero Bugs found for given criteria.");
		} else {
			System.out.println("Some Bugs are found for given criteria.");
		}
		File scrFile=((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File("ScreenShot\\ZeroSearchResult.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
   @BeforeTest
  public void beforeTest() {
	   wd=new FirefoxDriver();
		wd.get("https://hjbugzilla.persistent.co.in/ELTP2011/?GoAheadAndLogIn=1");
		wd.manage().window().maximize();
		wd.findElement(By.id("Bugzilla_login")).sendKeys("tester001@persistent.co.in");
		wd.findElement(By.id("Bugzilla_password")).sendKeys("tester001");
		wd.findElement(By.id("log_in")).click();
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		if (wd.getTitle().equals("Bugzilla Main Page")) {
			  System.out.println("Login to Bugzilla is successful!!!!");
			
		} else {
				System.out.println("BugZill Main page is not displayed. please check");
				wd.quit();
		}
  }

  @AfterTest
  public void afterTest() {
	  wd.findElement(By.linkText("Log out")).click();
	  wd.quit();
  }

}
