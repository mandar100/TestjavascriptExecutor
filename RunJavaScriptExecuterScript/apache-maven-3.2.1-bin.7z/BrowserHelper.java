package automation.commonfunctions;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



/**
 * @author anshul_nayak
 *
 */

public class BrowserHelper {
	
	public static WebDriver driver;
	
	public enum SearchOptions { EXACT, PARTIAL }  
	
	//System.out.println("   --  "+currentDirFile.getAbsolutePath());
	
	/**
	 * It will initialize browser.
	 * @param settings
	 */
	public static void browserINIT(String[] settings) {
		try {
			File currentDirFile = new File(".");
			switch (CommonFunctions.browser) {
			case "chrome":
				System.setProperty("webdriver.chrome.driver",currentDirFile.getAbsolutePath().replace(".", "Utils\\chromedriver.exe"));
				driver = new ChromeDriver();
				break;
			case "ie":
				System.setProperty("webdriver.ie.driver",currentDirFile.getAbsolutePath().replace(".", "Utils\\IEDriverServer.exe"));
				driver = new InternetExplorerDriver();
				break;	
			case "ff":
				driver = new FirefoxDriver();
				break;
			case "safari":
				driver = new FirefoxDriver();
				break;
			default:
				throw new Exception("Please specify browser in property file.");				
			}			
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);			
		} catch (Exception e) {
			System.out.println(""+e.getMessage()+"\n STACK TRACE -- ");
			e.printStackTrace();
		}finally{
			if(driver == null)
				System.out.println("File not found!!!");	
		}
	}
	
	/**
	 * It will click on element based on 'ele' reference.
	 * @param ele
	 * @param btnName
	 * @param pageName
	 */
	public static void clickOnElement(WebElement ele, String btnName, String pageName) {
		//Remove after demo////
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//Remove after demo////
		
		
		try {
			if(ele != null){				
				int timeout=0;
				while(timeout<5000){
					if(ele.isEnabled()){
							ele.click();
							timeout=5000;
					}
					else{
						timeout += 1000;
						Thread.sleep(1000);
					}
				}
				System.out.println("Button "+btnName+" clicked on '"+pageName+"'");
			}
			else{
				System.out.println("Please pass element");
				Assert.assertFalse("Please pass element", true);
			}
		}catch(NoSuchElementException ex){
			System.out.println("Element not found exception:"+ex.getMessage());
			Assert.assertFalse(ex.getMessage(), true);
		} catch (Exception e) {
			System.out.println("Exception in click method - "+e.getMessage());
			Assert.assertFalse(e.getMessage(), true);
		}
	}
	
	
	/**
	 * It will return title of current page. 
	 * @return string
	 */
	public static String getTitleOfPage(){
		String title = driver.getTitle();
		System.out.println("Title of page" +title); // Assertion
		//Assert.assertEquals(title, titleOfPage,"comparing titles");
		return title;
	}
	
	/// <summary>
    /// Navigate to URL
    /// </summary>
    /// <param name="URLToLaunch">Pass the URL you want to launch</param>
    /**
     * @param URLToLaunch
     * Pass the URL you want to launch
     */
    public static void navigateToURL(String URLToLaunch)
    {
        try
        {
        	driver.navigate().to(URLToLaunch);
            //FileOperations.logFile("Navigate to URL " + URLToLaunch, FileOperations.LogStatus.Pass);
            Thread.sleep(3000);
            String url = driver.getCurrentUrl();
            if (url == URLToLaunch)
            {
                //FileOperations.logFile("Successfully navigated on URL " + URLToLaunch, FileOperations.LogStatus.Pass);
            }
            else
            {
                //FileOperations.logFile("Navigation on URL " + URLToLaunch + " is failed", FileOperations.LogStatus.Fail);
            }
        }
        catch (Exception uri)
        {
           // FileOperations.logFile("Invalid URL" + uri.getMessage(), FileOperations.LogStatus.Fail);
        }
    }
	
    /*public static void SetValueOfElementByJavascript(String element, String newValue, By locator)
    {
        switch (locator)
        {
            case ByClassName:
                ((JavascriptExecutor)driver).executeScript(String.format("document.getElementById('{0}').value = '{1}';", element, newValue));
                break;
            case ByLocator.ClassName:
            	((JavascriptExecutor)driver).executeScript(String.format("document.getElementByClassName('{0}').value = '{1}';", element, newValue));
                break;
            case ByLocator.Name:
                ExecuteJavascript(String.format("document.getElementsByName('{0}').value = '{1}';", element, newValue));
                break;
            case ByLocator.TagName:
                ExecuteJavascript(String.format("document.getElementsByTagName('{0}').value = '{1}';", element, newValue));
                break;
            default:
                throw new Exception("Please specify appropriate Locator...");
        }
        //FileOperations.logFile("Attribute has been set for element " + element + ". New value is :" + newValue, FileOperations.LogStatus.Pass);
    }*/
    
    /**
     * Click on element using java script.
     * @param element
     */
    public static void clickOnElementByJavascript(WebElement element)
    {   
        ((JavascriptExecutor)driver).executeScript("arguments[0].click();", element);
    }
    
    /**
     * Verify exact text on element(text box).
     * @param webElement
     * @param textToVerify
     * @return
     */
    public static boolean verifyTextInTextBox(WebElement webElement, String textToVerify, SearchOptions option)
    {
        try
        {     
        	boolean result=false;
            switch (option) {
			case EXACT:
				if (webElement.getText().equals(textToVerify))
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Pass, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is present on page.");
					result = true;
	            }
	            else
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Fail, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is not present on page.");
	            	result = false;
	            }      
				break;
			case PARTIAL:
				if (webElement.getText().contains(textToVerify))
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Pass, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is present on page.");
					result = true;
	            }
	            else
	            {
	             //   FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Fail, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is not present on page.");
	            	result = false;
	            }    
				break;

			default:
				result = false;
				break;
			}
        	return result;         
        }
        catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
        	return false;
        }
        catch (Exception ex)
        {
           // FileOperations.logFile("Error while verifying text in textbox" + ex.Message, FileOperations.LogStatus.Fail);
        	return false;
        }
    }
        
    /**
     * Verify exact text on element.
     * @param webElement
     * @param attributeName
     * @param textToVerify
     * @return
     */
    public static boolean verifyTextOfElementByGetAttribute(WebElement webElement, String attributeName, String textToVerify, SearchOptions option){
    	try{
    		boolean result=false;
            switch (option) {
			case EXACT:
				if (webElement.getAttribute(attributeName).equals(textToVerify))
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Pass, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is present on page.");
					result = true;
	            }
	            else
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Fail, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is not present on page.");
	            	result = false;
	            }      
				break;
			case PARTIAL:
				if (webElement.getAttribute(attributeName).contains(textToVerify))
	            {
	                //FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Pass, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is present on page.");
					result = true;
	            }
	            else
	            {
	             //   FileOperations.logFile("Verifying text " + textToVerify + "", FileOperations.LogStatus.Fail, "", "" + textToVerify + " should present on Page", "" + textToVerify + " is not present on page.");
	            	result = false;
	            }    
				break;

			default:
				result = false;
				break;
			}
        	return result;   
    		
    	} catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
        	return false;
        }        
        catch (Exception ex)
        {
           // FileOperations.logFile("Error while verifying text in textbox" + ex.Message, FileOperations.LogStatus.Fail);
        	return false;
        }
    }
    
    /**
     * Verify if element is present.
     * @param by
     * @param nameOfElelment
     * @return
     */
    public static Boolean isElementPresent(By by, String nameOfElelment)
    {
        try
        {
        	getTitleOfPage();
            driver.findElement(by);
            //FileOperations.logFile("Verifying element " + nameOfElelment + " present on page.", FileOperations.LogStatus.Pass, "", "" + nameOfElelment + " should present on Page", "" + nameOfElelment + " is present on page.");
            return true;
        }
        catch (NoSuchElementException e)
        {
           // FileOperations.logFile("Verifying element " + nameOfElelment + " present on page.", FileOperations.LogStatus.Fail, "", "" + nameOfElelment + " should present on Page", "" + nameOfElelment + " is not present on page.");
            return false;
        }
    }
    
    /**
     * Set / insert text in element.
     * @param webElement
     * @param textToSend
     * @param nameOfElement
     */
    public static void setText(WebElement webElement, String textToSend, String nameOfElement)
    {
        try
        {
            webElement.clear();
            webElement.sendKeys(textToSend);
            //FileOperations.logFile("Setting text " + textToSend + " for " + nameOfElement + "", FileOperations.LogStatus.Pass, "", "Text " + textToSend + " for " + nameOfElement + "  is set.");
        }
        catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
        }
    }
    
    /**
     * Verify if Alert is present.
     * @return
     */
    public static boolean isAlertPresent()
    {
        try
        {
        	driver.switchTo().alert();           
            //FileOperations.logFile("Alert is present", FileOperations.LogStatus.Pass);
            return true;
        }
        catch (NoAlertPresentException msg)
        {
            //FileOperations.logFile("Alert is not present", FileOperations.LogStatus.Fail);
            return false;
        }
    }
    
  
    /**
     * Click on OK button on Alert.
     * @return
     */
    public static boolean acceptAlert()
    {
        if(isAlertPresent()){
        	driver.switchTo().alert().accept();
        	//FileOperations.logFile("Accepting Alert", FileOperations.LogStatus.Pass);
        	return true;
        }else{
        	//FileOperations.logFile("Accepting Alert", FileOperations.LogStatus.Pass);
        	return false;
        }
    }

    /**
     * Verify text on alert.
     * @param text
     * @return
     */
    public static boolean verifyTextOnAlert(String text)
    {
        
        if (isAlertPresent() && driver.switchTo().alert().getText().contains(text)){
            //FileOperations.logFile("Alert Text verified correctly ", FileOperations.LogStatus.Pass);
        	return true;
        }else{
            //FileOperations.logFile("Alert Text not verified correctly ", FileOperations.LogStatus.Fail);
        	return false;
        }
    }

    
    /**
     * Click on cancel button on alert.
     */
    public static void dismissAlert()
    {
        if(isAlertPresent()){
	        driver.switchTo().alert().dismiss();
	        //FileOperations.logFile("Cancelling the Alert", FileOperations.LogStatus.Pass);
        }else{
        	//FileOperations.logFile("Alert not present", FileOperations.LogStatus.Fail);
        }
    }
    
    /**
     * Select element from drop down using text.
     * @param element
     * @param textToSelect
     * @param nameOfElement
     */
    public static void selectElementFromDropdownUsingText(WebElement element, String textToSelect, String nameOfElement)
    {
        try
        {	
            Select elementToSelect = new Select(element);
            Thread.sleep(2000);
            elementToSelect.selectByValue(textToSelect);
        }
        catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return; 
        }
        catch (Exception ex)
        {
           // FileOperations.logFile("Error while selecting element from dropdown" + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    /**
     * @param element
     * @param textToSelect
     * @param nameOfElement
     */
    public static void selectElementFromDropdownUsingIndex(WebElement element, int indexToSelect, String nameOfElement)
    {
        try
        {	
            Select elementToSelect = new Select(element);
            Thread.sleep(2000);
            elementToSelect.selectByIndex(indexToSelect);
        }
        catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return; 
        }
        catch (Exception ex)
        {
           // FileOperations.logFile("Error while selecting element from dropdown" + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    /**
     * @param element
     * @param textToSelect
     * @param nameOfElement
     */
    public static void selectElementFromDropdownUsingVisibleText(WebElement element, String textToSelect, String nameOfElement)
    {
        try
        {	
            Select elementToSelect = new Select(element);
            Thread.sleep(2000);
            elementToSelect.selectByVisibleText(textToSelect);
        }
        catch (NoSuchElementException e)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return; 
        }
        catch (Exception ex)
        {
           // FileOperations.logFile("Error while selecting element from dropdown" + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    /**
     * @param element
     * @param partialtext
     * @param nameOfElement
     */
    public static void selectElementFromDropdownByPartialText(WebElement element, String partialtext, String nameOfElement)
    {
        try
        {
            element.findElement(By.xpath("//option[contains(text(),'" + partialtext + "')]")).click();
            Thread.sleep(2000);
            //FileOperations.logFile("Selecteing " + nameOfElement + " as " + partialtext + "", FileOperations.LogStatus.Pass, "", "" + nameOfElement + " as " + partialtext + " should be selected.", "" + nameOfElement + " as " + partialtext + " is selected.");
        }
        catch (NoSuchElementException ex)
        {
            //FileOperations.logFile("Element is not found in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return;
        }
        catch (Exception ex)
        {
            //FileOperations.logFile("Error while selecting element from dropdown" + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    
    /**
     * It will switch to frame depending on either frame name or index. So in parameter send frame name as null if want to 
     * switch using INDEX, and index=0 and frame name if want to switch using frame.
     * @param frameName
     * @param frameIndex
     */
    public static void switchToFrame(String frameName, int frameIndex)
    {
        try
        {	
            List<WebElement> frames = driver.findElements(By.tagName("iframe"));
            for (WebElement frame : frames) {
            	if (frame.getAttribute("Name").equals(frameName))
                {
                    driver.switchTo().frame(frame);
                    break;
                }
                else if (frame.getAttribute("index").equals(frameIndex))
                {
                    driver.switchTo().frame(frame);
                    break;
                }
            }
        }
        catch (NoSuchFrameException ex)
        {
            //FileOperations.logFile("Frame is not in Function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return;
        }
        catch (Exception ex)
        {
            //FileOperations.logFile("Attribute 'Name' is not foud for Frame in function " + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType + " Meassage is " + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    /**
     * It will wait for alert for given time. Work as Explicit wait
     * @param maxSecondsToWait
     */
    public static void waitForAlertPresent(int maxSecondsToWait)
    {
            new WebDriverWait(driver, TimeUnit.SECONDS.toSeconds(maxSecondsToWait)).until(ExpectedConditions.alertIsPresent() );
    }
    
    /*public static boolean verifyIsTitlePresent(String titleToVerify, SearchOptions option = SearchOptions.Partial, String pageName=null)
    {
        try
        {
            // Thread.Sleep(1000);
            IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(HtmlControls._webDriver, TimeSpan.FromSeconds(30.00));
            if (option == SearchOptions.Partial)
            {
                if (_webDriver.Title.Contains(titleToVerify))
                {
                    FileOperations.logFile("Verify " + titleToVerify + " page is displayed or NOT", FileOperations.LogStatus.Pass, "", "" + titleToVerify + " page should be displayed", "" + titleToVerify + " page is displayed");
                    return true;
                }
                else
                {
                    FileOperations.logFile("Verify " + titleToVerify + " page is displayed or NOT", FileOperations.LogStatus.Fail, "", "" + titleToVerify + " page should be displayed", "" + titleToVerify + " page is NOT displaying");
                    return false;
                }
            }
            else
            {
                if (_webDriver.Title.Equals(titleToVerify))
                {
                    FileOperations.logFile("Verify " + titleToVerify + " page is displayed or NOT", FileOperations.LogStatus.Pass, "", "" + titleToVerify + " page should be displayed", "" + titleToVerify + " page is displayed");
                    return true;
                }
                else
                {
                    FileOperations.logFile("Verify " + titleToVerify + " page is displayed or NOT", FileOperations.LogStatus.Fail, "", "" + titleToVerify + " page should be displayed", "" + titleToVerify + " page is NOT displaying");
                    return false;
                }
            }
        }
        catch (Exception ex)
        {
            FileOperations.logFile("Error while searching title." + ex.Message, FileOperations.LogStatus.Fail);
            return false;
        }
    }*/
    
    public static void SetCheckbox(WebElement webElement, Boolean valueToSet, String nameOfCheckbox)
    {
        try
        {
            if (valueToSet == true)
            {
                if (!webElement.isSelected())
                {

                    webElement.click();
                    Thread.sleep(2000);

                    if (webElement.isSelected())
                    {
                       // FileOperations.logFile("Verify " + nameOfCheckbox + " checkbox is selected or NOT", FileOperations.LogStatus.Pass, "", "" + nameOfCheckbox + " checkbox should be selected", "" + nameOfCheckbox + " checkbox is selected to" + valueToSet);
                    }
                    else
                    {
                      //  FileOperations.logFile("Verify " + nameOfCheckbox + " checkbox is selected or NOT", FileOperations.LogStatus.Fail, "", "" + nameOfCheckbox + " checkbox should be selected", "" + nameOfCheckbox + " checkbox is not selected to" + valueToSet);
                    }

                }
            }
            else
            {
                if (webElement.isSelected())
                {
                    webElement.click();
                    Thread.sleep(2000);
                    if (!webElement.isSelected())
                    {
                      //  FileOperations.logFile("Verify " + nameOfCheckbox + " checkbox is selected or NOT", FileOperations.LogStatus.Pass, "", "" + nameOfCheckbox + " checkbox should be selected", "" + nameOfCheckbox + " checkbox is selected to " + valueToSet);
                    }
                    else
                    {
                      //  FileOperations.logFile("Verify " + nameOfCheckbox + " checkbox is selected or NOT", FileOperations.LogStatus.Fail, "", "" + nameOfCheckbox + " checkbox should be selected", "" + nameOfCheckbox + " checkbox is not selected to " + valueToSet);

                    }
                }
            }

        }
        catch (StaleElementReferenceException msg)
        {
           // FileOperations.logFile("Error while accessing element in function" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, FileOperations.LogStatus.Fail);
            return;
        }
        catch (Exception ex)
        {
            //FileOperations.logFile("Error while setting radio button" + ex.Message, FileOperations.LogStatus.Fail);
            return;
        }
    }
    
    /*public static WebDriver SwitchToParentWindow()
    {
        return switchToWindow(0);
    }*/
    
    /*public static IWebDriver switchToWindow(int index)
    {
    	WebDriverWait wait = new WebDriverWait(driver, TimeUnit.SECONDS.toSeconds(30));
        wait.Until(<T>   d => d.WindowHandles.Count > index);
        return driver.switchTo().window(arg0)    window(driver.getWindowHandle().indexOf(index));
    }*/

     /**
      * It will return window handle of given title.
     * @param title
     * @return window handle of given title.
     */
    public static WebDriver switchToWindow(String title)
    {
    	 WebDriverWait wait = new WebDriverWait(driver, TimeUnit.SECONDS.toSeconds(30));
        wait.until(ExpectedConditions.titleContains(title));
        return driver.switchTo().window(title);
    }
    
    
}
