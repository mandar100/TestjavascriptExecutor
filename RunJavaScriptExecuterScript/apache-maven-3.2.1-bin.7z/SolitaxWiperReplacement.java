package automation.tests;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.*;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;
import automation.framework.pages.DeviceListPage;
import automation.framework.pages.LoginPage;
import automation.framework.pages.PutSensorBackInProcessPage;
import automation.framework.pages.SolitaxCleaningCarouselPage;
import automation.framework.pages.SolitaxCleaningFirstPage;
import automation.framework.pages.SolitaxDeviceDetailsPage;
import automation.framework.pages.SolitaxMaintenancePage;
import automation.framework.pages.SolitaxWiperActivation;
import automation.framework.pages.SolitaxWiperReplaceCarouselPage;
import automation.framework.pages.SolitaxWiperReplaceFirstPage;

/**
 * @author Nilesh_dharmadhikari
 *
 */

public class SolitaxWiperReplacement {

	private WebDriver fusionDriver;

	String sensorId = "HL001_00104_000000000102";		
	String home_page_title = "Devices - Fusion";
	String identifier = "Solitax:WiperReplace";
	
	@BeforeTest
	public void setup(){
		File currentDirFile = new File(".");		
		String configFilePath = currentDirFile.getAbsolutePath().replace(".", "Resources\\config.properties");
		
		CommonFunctions.readConfiPropertiesFile(configFilePath);
		
		currentDirFile = new File(".");
		String dir = currentDirFile.getAbsolutePath().replace(".", "TestData\\SensorInputData.xlsx");		
		CommonFunctions.getWorkflowSpecificDataFromSensorDetailsRecord(dir,"SolitaxWiperReplacement");	
		
		BrowserHelper.browserINIT(null);
		fusionDriver = BrowserHelper.driver;	
	}
	@AfterTest
	public void tearDown(){
		fusionDriver.quit();
	}		
	
	@Test(priority=1)
	public void verifyLogin(){
		LoginPage lp = new LoginPage();
		lp.loginToApplication();
		String deviceListPageTitle = BrowserHelper.getTitleOfPage();
		Assert.assertEquals(deviceListPageTitle,home_page_title,"Login failed");
	}
	
	
	@Test(priority=2)
	public void verifyDeviceListPage(){
		//TODO: Verify PAGE UI 
	}
	@Test(priority=3)
	public void verifySensorCount(){
		DeviceListPage dlp= new DeviceListPage();
		
		dlp.checkNoOfSensors(10);
		dlp.clickSensorOnDeviceListPage(sensorId);
	}
	
	@Test(priority=4)
	public void verifyDeviceDetailsPage(){
		//TODO: Verify PAGE UI 
	}
	
	@Test(priority=5)
	public void verifyNavigateToSolitaxWiperReplacementPage1(){
		SolitaxMaintenancePage smp = new SolitaxMaintenancePage();
		SolitaxWiperReplaceFirstPage scp = new SolitaxWiperReplaceFirstPage();
		DeviceListPage dlp= new DeviceListPage();
		try {
			CommonFunctions.startWorkflow(fusionDriver, "Wiper blade replacement", "Wiper replacement", "Device Details Page",sensorId);
			scp.checkPageHeader();				
			Assert.assertTrue(scp.isBackArrowPresentInHeader(),"Back Arrow not present");
			Assert.assertTrue(scp.isHoldActivePanelIsPresent(),"Hold Active pannel is not present");
			Assert.assertTrue(scp.isSafetyInformationLinkPresent(),"Safety info link is not present");				
			scp.clickOnBackArrowPresentInHeader();				
			dlp.clickMaitenanceNotificationBanner(identifier);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority=6)
	public void solitaxWiperReplaceWorkFlow() throws Exception{
		SolitaxWiperReplaceFirstPage scp = new SolitaxWiperReplaceFirstPage();
		
		SolitaxMaintenancePage smp = new SolitaxMaintenancePage();
		SolitaxWiperActivation swap = new SolitaxWiperActivation();
		PutSensorBackInProcessPage psbipp = new PutSensorBackInProcessPage();
		WebDriverWait wait = new WebDriverWait(fusionDriver,30);
		SolitaxWiperReplaceCarouselPage swcp = new SolitaxWiperReplaceCarouselPage();
		
		fusionDriver.findElement(By.cssSelector("button[id='continueButton']")).click();
		swcp.verifyCarouselPageForSolitaxWiperReplace(sensorId);
		swap.verifyTimeOutAndErrorPopup(sensorId);
		swap.wiperActivation(sensorId);
		fusionDriver.findElement(By.cssSelector("button[id='continueButton']")).click();
		psbipp.clickOnDoneButton();
		wait.until(ExpectedConditions.titleContains(BrowserHelper.getTitleOfPage()));
		fusionDriver.findElement(By.xpath("html/body/div[2]/div[4]/a")).click();
	}
}
