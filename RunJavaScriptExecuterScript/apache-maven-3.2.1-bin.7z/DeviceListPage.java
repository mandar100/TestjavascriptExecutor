package automation.framework.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;

/**
 * @author Shubhangi_Pote
 *
 */
public class DeviceListPage {

	WebDriver fusionDriver;
	@FindBy(id="dvTitleHome")
	private WebElement deviceListTitleText;	
	By solitaxSensor = By.xpath("");	 
	
	public DeviceListPage(){
		this.fusionDriver= BrowserHelper.driver;
	}
	
	public boolean isSensorPresentInDeviceList(String fid){	
		return true;
	}
	public boolean verifyDeviceListingPageIsDisplayed(){
		if (deviceListTitleText.getText().equalsIgnoreCase("Home")) {
			return true;
		}
		else
			return false;
	}
	
	public void clickOnSolitaxSensor(String fid){
		fusionDriver.findElement(solitaxSensor).click();
		//String pageTitle= CommonFunctions.getTitleOfPage(this.driver);	
		// TO DO : Assertion to verify that user has been navigated to device details page()
		
	}
	
	public boolean checkWFNotificatonLogoPresent(String fid){
		// TO DO : Assertion to verify that notification logo exists on device list page for sensor. For now returning true 
		return true;
	}
	
	// Identify methods and decide if that should go in common or on page itself
	
	public void clickSensorOnDeviceListPage(String sensorId){
		fusionDriver.findElement(By.cssSelector("a[href='Device/Details/"+sensorId+"']")).click();
	}
	
	/*
	 * This method is to click on maintenance notification banner as per selected sensor and workflow
	 * 
	 * */
	public void clickMaitenanceNotificationBanner(String identifier){
		switch(identifier){
		case "Solitax:Cleaning":
		fusionDriver.findElement(By.xpath("//a[starts-with(@href, '/SolitaxMaintenance/ManualSensorCleaningStep1')]")).click();
		break;
		case "Solitax:WiperReplace":
		fusionDriver.findElement(By.xpath("//a[starts-with(@href, '/SolitaxMaintenance/Index')]")).click();
		break;
		case "Solitax:Calibration":
		fusionDriver.findElement(By.cssSelector("a[data-toggle='modal']")).click();
		break;	
		}
	}
	
	public void checkNoOfSensors(int num){
		int list = fusionDriver.findElements(By.xpath("//ul[@id='sensorList']/li")).size();
		System.out.println(list);
        Assert.assertEquals(list,num,"The number does not match with expected number");
	}

}
