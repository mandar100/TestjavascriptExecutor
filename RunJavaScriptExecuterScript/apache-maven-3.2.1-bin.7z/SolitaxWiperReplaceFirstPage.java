package automation.framework.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.google.common.base.Verify;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;

public class SolitaxWiperReplaceFirstPage {

	WebDriver driver;
	CommonFunctions cf;
	
	@FindBy(xpath=".//*[@id='cautionModal']/div")
	WebElement popup;	
	@FindBy(xpath = ".//*[@id='dvTitleHome']")
	WebElement pageHeaderText;
	@FindBy(xpath=".//*[@id='navBar']/div/a/div")
	WebElement backArrow;
	@FindBy(xpath=".//*[@id='frmOutputVal']/div")
	WebElement outputHoldActivePanel;
	@FindBy(xpath="html/body/div[2]/a/div/div/div/span[2]")
	WebElement safetyInfoLink;
	@FindBy(xpath=".//*[@id='frmOutputVal']/div/div[2]/div/button[1]")
	WebElement holdBtn;
	@FindBy(xpath=".//*[@id='frmOutputVal']/div/div[2]/div/button[2]")
	WebElement activeBtn;
	@FindBy(id="cancelButton")
	WebElement cancelBtn;
	@FindBy(id="continueButton")
	WebElement continueBtn;	
	
	private String expectedWFPage1Header = "Wiper blade replacement";
	private String expectedWFPage2Title ="Wiper blade replacement - Fusion";
	private String expectedDeviceDetailsPageTitle ="Sensor Details - Fusion";
	private String expectedBackgroundColorBlue ="#0098db";
	private String expectedBackgroundColorWhite ="#fff";
	
	public SolitaxWiperReplaceFirstPage(){
		this.driver = BrowserHelper.driver;
		//This initElements method will create all WebElements
		PageFactory.initElements(this.driver, this);
	}
	
	public void checkPageHeader(){
		By heading = By.xpath(".//*[@id='dvTitleHome']");
		String actTitle = driver.getTitle();
		String actHeadingText = driver.findElement(heading).getText();
		Assert.assertEquals(expectedWFPage1Header,actHeadingText,"verifying heading of page");
		Assert.assertEquals(expectedWFPage2Title,actTitle,"verifying title of page");
	}
	
	/**
	 * Verifies if back arrow present in header
	 * @return : true if back arrow present in header
	 */
	public Boolean isBackArrowPresentInHeader(){
		By backArrow = By.xpath(".//*[@id='navBar']/div/a/div");
		String missingBackArrowInHeader = "Back arrow is missing in header on page1";
		boolean isElementPresent = (driver.findElements(backArrow).size()==1);
		//Assert.assertTrue(isElementPresent,missingBackArrowInHeader);
		return isElementPresent;
	}
	
	/**
	 * Verifies user has been navigated to device details page if user clicks on back arrow
	 */
	public void clickOnBackArrowPresentInHeader(){;
		BrowserHelper.clickOnElement(backArrow, "", "");
		
		String pageTitle= BrowserHelper.getTitleOfPage();
		if(CommonFunctions.SensorNameFromSensorInputData!=null)
		{
			expectedDeviceDetailsPageTitle = CommonFunctions.SensorNameFromSensorInputData+" - SOLITAX sc - Fusion";
		}
		else
		{
			expectedDeviceDetailsPageTitle = "- SOLITAX sc - Fusion";
		}
		Assert.assertEquals(pageTitle,expectedDeviceDetailsPageTitle,"User is not navigated to device list page of solitax sensor"+CommonFunctions.SensorIdFromSensorInputData);
	}
	
	/**
	 * Verifies if Hold Active panel is present on page
	 * @return : true if Hold Active panel is present on page
	 */
	public boolean isHoldActivePanelIsPresent(){
	  boolean isElementPresent =(outputHoldActivePanel.isEnabled());
	  Assert.assertTrue(isElementPresent,"verifying Hold Active panel");
	  return isElementPresent;
	}
	
	/**
	 * Verifies functionality of hold option
	 */
	public void selectHold(){
		BrowserHelper.clickOnElement(holdBtn, "hold button", "Page 1");		
		String holdBtnBackgroundColor = holdBtn.getText();
		String activeBtnBackgroundColor = activeBtn.getText();
		Assert.assertEquals(holdBtnBackgroundColor,expectedBackgroundColorBlue,"verifying hold button color");
		Assert.assertEquals(activeBtnBackgroundColor,expectedBackgroundColorWhite,"verifying active button color");
	}
	
	/**
	 * Verifies functionality of active option
	 */
	public void selectActive(){
		BrowserHelper.clickOnElement(activeBtn, "Active button", "Page 1");
		//driver.findElement(activeBtn).click();
		String holdBtnBackgroundColor = holdBtn.getText();
		String activeBtnBackgroundColor = activeBtn.getText();
		Assert.assertEquals(activeBtnBackgroundColor,expectedBackgroundColorBlue,"verifying active button color");
		Assert.assertEquals(holdBtnBackgroundColor,expectedBackgroundColorWhite,"verifying hold button color");		
	}
	
	/**
	 * Verifies if Safety information link is present
	 * @return : true if Safety information link is present
	 */
	public boolean isSafetyInformationLinkPresent(){
		boolean isElementPresent = (safetyInfoLink.isDisplayed());
		Assert.assertTrue(isElementPresent,"verifying safety information link");
		return isElementPresent;
	}
	
	/**
	 * Verifies cancel button functionality
	 */
	public void cancelWFFromPage1(){
		BrowserHelper.clickOnElement(cancelBtn, "cancel button", "Page 1");
		
		Assert.assertEquals(BrowserHelper.getTitleOfPage(),expectedDeviceDetailsPageTitle,"verifying device details page" );		
	}
	
	/**
	 * Verifies continue button functionality
	 */
	public void continueWFFromPage1(){
		BrowserHelper.clickOnElement(continueBtn, "Continue", "Page 1");
		
		Assert.assertEquals(BrowserHelper.getTitleOfPage(),expectedWFPage2Title,"clicking continue button" );
	}
	
	/**
	 * Verifies that safety information link functionality is working
	 * @return true if popup appears
	 */
	public boolean clickOnSafetyInformationLink(){				
		boolean isPopupPresent = (popup.isDisplayed());
		Assert.assertTrue(isPopupPresent,"verifying safety info popup");
		return isPopupPresent;		
	}
}
