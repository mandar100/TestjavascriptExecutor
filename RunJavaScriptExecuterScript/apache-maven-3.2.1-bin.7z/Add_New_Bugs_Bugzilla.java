package testNG_Assignment;


import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;


public class Add_New_Bugs_Bugzilla  {
	private WebDriver wd;
  @Test(dataProvider = "Bug details")
  public void logBugsUsingData(String component, String critical, String Hardware, String OS,String priority,String description,String comment) 
  {
	wd.findElement(By.linkText("New")).click();
	wd.findElement(By.linkText("Flight Reservation")).click();
	if (wd.getTitle().equals("Enter Bug: Flight Reservation")&&wd.findElement(By.id("expert_fields_controller")).getText().equals("Show Advanced Fields")) 
	{
		wd.findElement(By.id("expert_fields_controller")).click();
	}
	if (requiredFieldsPresent()) {
		wd.findElement(By.name("component")).sendKeys(component);
		wd.findElement(By.name("bug_severity")).sendKeys(critical);
		wd.findElement(By.name("rep_platform")).sendKeys(Hardware);
		wd.findElement(By.name("op_sys")).sendKeys(OS);
		wd.findElement(By.name("priority")).sendKeys(priority);
		wd.findElement(By.name("short_desc")).sendKeys(description);
		wd.findElement(By.name("comment")).sendKeys(comment);
		wd.findElement(By.id("commit")).click();		
	}
	else
	{
		System.out.println("required fields are not present... please check with website Administrator.....");		
		wd.close();
	}
	
	
  }
  private boolean requiredFieldsPresent() {
	// TODO Auto-generated method stub
	  if (wd.findElement(By.name("component")).isDisplayed()&&wd.findElement(By.name("bug_severity")).isDisplayed()&&wd.findElement(By.name("rep_platform")).isDisplayed()&&wd.findElement(By.name("op_sys")).isDisplayed()&&wd.findElement(By.name("priority")).isDisplayed()&&wd.findElement(By.name("short_desc")).isDisplayed()&&wd.findElement(By.name("comment")).isDisplayed()) {
		return true;
	} else {
		return false;
	}
	
}
@DataProvider(name="Bug details")	
  public Object[][] bugDetailsData() {
   return new Object[][] {
     { "Module1", "critical","Macintosh","Mac OS","P1","Selenium MOC Test bug 1 for 007878","Selenium MOC Test bug  description 1 for 007878" },
     { "Team A", "blocker","All","Windows","P2","Selenium MOC Test bug 2 for 007878","Selenium MOC Test bug  description 2 for 007878" },
     { "Team B", "major","All","Linux","P3","Selenium MOC Test bug 3 for 007878","Selenium MOC Test bug  description 3 for 007878" },
     { "Module1", "normal","All","Other","P4","Selenium MOC Test bug 4 for 007878","Selenium MOC Test bug  description 4 for 007878" },
     { "Team A", "minor","All","All","P5","Selenium MOC Test bug 5 for 007878","Selenium MOC Test bug  description 5 for 007878" },
   }; 
  } 
  
  @BeforeTest
  public void beforeTest() {
	  wd=new FirefoxDriver();
		wd.get("https://hjbugzilla.persistent.co.in/ELTP2011/?GoAheadAndLogIn=1");
		wd.manage().window().maximize();
		wd.findElement(By.id("Bugzilla_login")).sendKeys("tester002@persistent.co.in");
		wd.findElement(By.id("Bugzilla_password")).sendKeys("tester002");
		wd.findElement(By.id("log_in")).click();
		if (wd.getTitle().equals("Bugzilla Main Page")) {
			  System.out.println("Login to Bugzilla is successful!!!!");
			
		} else {
				System.out.println("BugZill Main page is not displayed. please check");
				wd.quit();
		}
  }

  @AfterTest
  public void afterTest() {
	  wd.findElement(By.linkText("Log out")).click();
	  wd.quit();
  }

}
