/**
 * 
 */
package automation.tests;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;
import automation.framework.pages.DeviceListPage;
import automation.framework.pages.LoginPage;
import automation.framework.pages.PutSensorBackInProcessPage;
import automation.framework.pages.SolitaxCleaningCarouselPage;
import automation.framework.pages.SolitaxCleaningFirstPage;
import automation.framework.pages.SolitaxMaintenancePage;
import automation.framework.pages.SolitaxWiperActivation;

/**
 * @author Nilesh_dharmadhikari
 *
 */
public class SolitaxCleaningWorkflow {
	
		
		private WebDriver fusionDriver;

		String sensorId = "HL001_00104_000000000102";		
		String home_page_title = "Devices - Fusion";
		String identifier = "Solitax:Cleaning";
		
		@BeforeTest
		public void setup(){
			File currentDirFile = new File(".");		
			String configFilePath = currentDirFile.getAbsolutePath().replace(".", "Resources\\config.properties");
			
			CommonFunctions.readConfiPropertiesFile(configFilePath);
			BrowserHelper.browserINIT(null);
			fusionDriver = BrowserHelper.driver;	
		}
		@AfterTest
		public void tearDown(){
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			fusionDriver.quit();
		}		
		
		@Test(priority=1)
		public void verifyLogin(){
			LoginPage lp = new LoginPage();
			lp.loginToApplication();
			String deviceListPageTitle = BrowserHelper.getTitleOfPage();
			Assert.assertEquals(deviceListPageTitle,home_page_title,"Login failed");
		}
		
		
		@Test(priority=2)
		public void verifyDeviceListPage(){
			//TODO: Verify PAGE UI 
		}
		
		@Test(priority=3)
		public void verifySensorCount(){
			DeviceListPage dlp= new DeviceListPage();
			
			dlp.checkNoOfSensors(10);
			dlp.clickSensorOnDeviceListPage(sensorId);
		}
		
		@Test(priority=4)
		public void verifyDeviceDetailsPage(){
			//TODO: Verify PAGE UI 
		}
		
		@Test(priority=5)
		public void verifyNavigateToSolitaxCleaningPage1(){			
			//SolitaxMaintenancePage smp = new SolitaxMaintenancePage();
			SolitaxCleaningFirstPage scp = new SolitaxCleaningFirstPage();
			//DeviceListPage dlp= new DeviceListPage();
			try {
				//Start solitax cleaning work flow.
				CommonFunctions.startWorkflow(fusionDriver, "Cleaning", "Cleaning", "Device Details Page",sensorId);
				
				// Verify Solitax cleaning work flow page1
				scp.checkPageHeader();				
				Assert.assertTrue(scp.isBackArrowPresentInHeader(),"Back Arrow not present");
				Assert.assertTrue(scp.isHoldActivePanelIsPresent(),"Hold Active pannel is not present");
				Assert.assertTrue(scp.isSafetyInformationLinkPresent(),"Safety info link is not present");	
				Assert.assertTrue(BrowserHelper.isElementPresent(By.id("cancelButton"), "Cancel Button"), "Verify cancel button is present.");
				Assert.assertTrue(BrowserHelper.isElementPresent(By.id("continueButton"), "Continue Button"), "Verify continue button is present.");
				Assert.assertTrue(scp.isHoldActivePanelIsPresent(), "Verify hold/active panel is present.");
				
				//Click on back arrow to navigate device details page
				scp.clickOnBackArrowPresentInHeader();				
				//dlp.clickMaitenanceNotificationBanner(identifier);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		@Test(priority=6)
		public void solitaxCleaningWorkFlow() throws Exception {
		   
			SolitaxCleaningFirstPage scp = new SolitaxCleaningFirstPage();			
			SolitaxMaintenancePage smp = new SolitaxMaintenancePage();
			SolitaxWiperActivation wiperActivation = new SolitaxWiperActivation();
			PutSensorBackInProcessPage putSensorBack = new PutSensorBackInProcessPage();
			WebDriverWait wait = new WebDriverWait(fusionDriver,30);
			SolitaxCleaningCarouselPage carouselPages = new SolitaxCleaningCarouselPage();
			
			//Start cleaning work flow
			CommonFunctions.startWorkflow(fusionDriver, "Cleaning", "Cleaning", "Device Details Page",sensorId);
			
			//Click on continue button on page 1
			fusionDriver.findElement(By.cssSelector("button[id='continueButton']")).click();
			
			//Verify carousel page
			carouselPages.verifyCarouselPageForSolitaxCleaning(sensorId);
			wiperActivation.verifyTimeOutAndErrorPopup(sensorId);
			wiperActivation.wiperActivation(sensorId);
			fusionDriver.findElement(By.cssSelector("button[id='continueButton']")).click();
			putSensorBack.clickOnDoneButton();
			wait.until(ExpectedConditions.titleContains(BrowserHelper.getTitleOfPage()));
			fusionDriver.findElement(By.xpath("html/body/div[2]/div[4]/a")).click();
		}
		
}