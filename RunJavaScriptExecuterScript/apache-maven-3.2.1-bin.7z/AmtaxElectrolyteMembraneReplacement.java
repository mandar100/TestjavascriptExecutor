package automation.tests;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import automation.commonfunctions.BrowserHelper;

public class AmtaxElectrolyteMembraneReplacement {
	
	
	
	@Test
	public void navigateToAmtaxDeviceListPage() {
		
		
		  boolean one = true;
		  boolean two = false;
		  Assert.assertEquals(true, one);
		  Assert.assertEquals(true, two);
	}
	
	@Test
	public void verifyPageOne() {
		//On device list page start work flow
		boolean one = false;
		  boolean two = true;
		  Assert.assertTrue(one);
		  Assert.assertTrue(two);
		  
		  Assert.assertFalse(one);
		  Assert.assertFalse(two);
	}
	 
	@Test
	public void verifyPage1BackButton(){
		boolean one = false;
		  boolean two = true;
		  Assert.assertEquals(true, one);
		  Assert.assertEquals(true, two);
	}
	 
	@Test
	public void verifyPage2UI() {
		boolean one = true;
		  boolean two = false;
		  Assert.assertEquals(true, one);
		  Assert.assertEquals(true, two);
	}
	
	@Test
	public void verifypage2BackButton() {
		boolean one = true;
		  boolean two = false;
		  Assert.assertEquals(true, one);
		  Assert.assertEquals(true, two);
	}
	@Test
	public void verifypage2CancelButton() {
		boolean one = true;
		  boolean two = false;
		  Assert.assertEquals(true, one);
		  Assert.assertEquals(true, two);
	}
	
	@Test
	public void verifyMaintenancePopUpQuitButton() {
		boolean one = false;
		  boolean two = true;
	}
	  
	@Test
	public void verifyMaintenancePopUpCancelButton() {
		boolean one = false;
		  boolean two = true;
	}
	 
	@Test
	public void verifyPage3(){
		boolean one = true;
		  boolean two = false;
	}
	  
	@Test
	public void verifyPage3CancelButton(){
		boolean one = true;
		  boolean two = false;
	}
	  
	@Test
	public void verifyMaintenancePopUpQuitButtonPage3(){
		boolean one = true;
		  boolean two = true;
	}
  
}
