package com.secureBrowse;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class SecureBrowserTest {
	WebDriver secureDriver;
	  @Test
	  public void browseSecureSite() {
		  secureDriver.navigate().to("https://app2playground.cloudapp.net");
	  }
	  @BeforeTest
	  public void beforeTest() {
		  FirefoxProfile fp=new FirefoxProfile();
		  
		  fp.setAcceptUntrustedCertificates(false);
		  
		  secureDriver= new FirefoxDriver(fp);
	  }

	  @AfterTest
	  public void afterTest() {
	  }

}
