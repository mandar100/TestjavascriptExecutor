import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class TestRegistration {

	/**
	 * @param args
	 */
	static WebDriver driver;
	private static String firstName="Sachin";
	private static String lastName="Saurav";
	private static String phone="45751542";
	private static String userName="sachinsaurav@gmail.com";
	private static String address1="Surve no. 23/56, Malbar Hill";
	private static String address2="Near Wankhede Stadium, Mumbai";
	private static String city="Mumbai";
	private static String state="Maharashtra";
	private static String postalCode="400003";
	private static String country="INDIA";
	private static String email="SachinDada";
	private static String password="DadaSachin!@#";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://newtours.demoaut.com/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("REGISTER")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		RegisterPage registerPage=PageFactory.initElements(driver, RegisterPage.class);
		RegisterSuccess registerSuccessPage=registerPage.register(firstName, lastName, phone, userName, address1, address2, city, state, postalCode, country, email, password);
		registerSuccessPage.isRegistretSuccessful(firstName, lastName, email);
		
	}

}
