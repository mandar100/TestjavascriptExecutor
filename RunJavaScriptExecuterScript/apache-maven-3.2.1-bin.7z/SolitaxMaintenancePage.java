/**
 * 
 */
package automation.framework.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;

/**
 * @author Shubhangi_Pote
 *
 */
public class SolitaxMaintenancePage {

	WebDriver driver;
		
	public SolitaxMaintenancePage()
	{
		driver = BrowserHelper.driver; 
	}
	
	/**
	 * @param sensorId
	 * @param identifier
	 * @throws Exception
	 *//*
	public void triggerWorkFlow(String sensorId, String identifier) throws Exception{
		DeviceListPage deviceListPage = new DeviceListPage();
		WebDriverWait wait = new WebDriverWait(driver,30);
		boolean isNotificationPresent = false;
		String notificationHeaderName = null;
		WebElement triggerNowBtn = null;
		
		switch (identifier) {
		case "Solitax:Cleaning":
			notificationHeaderName = "Cleaning";
			
			break;
			
		case "Solitax:WiperReplace":
			notificationHeaderName = "Wiper";
			break;
			
		default:
			break;
		}
		//String identifier = "Solitax:Cleaning";
		
		List<WebElement> notifications = driver.findElements(By.xpath(".//*[@id='headerBar']/a"));
		
		for (WebElement notification : notifications) {
			 String notificationHeader =  notification.getText();
			 if(notificationHeader.contains(notificationHeaderName))
			 {
				isNotificationPresent = true;
			 }			 
		}
		
		if(!isNotificationPresent)
		{
			driver.findElement(By.cssSelector("a[href='/Device/MaintenanceManagement/"+sensorId+"']")).click();
			//driver.findElement(By.xpath("/html/body/div[2]/div[3]/div[2]/span")).click();
			BrowserHelper.clickOnElement(triggerNowBtn, "Trigger Now", "Solitax Maintenance");
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//*[@id='headerBar']/a[2]/div/div[2]/div")));
			CommonFunctions.takeSnap(driver, "./two.jpg");
		}
		
		deviceListPage.clickMaitenanceNotificationBanner(identifier);		
	}
	
	public void triggerWorkFlowForWiperReplace(String sensorId) throws Exception{
		DeviceListPage deviceListPage = new DeviceListPage();
		WebDriverWait wait = new WebDriverWait(driver,30);
		String identifier = "Solitax:WiperReplace";
		boolean isWiperReplaceNotificationPresent = false;
		
		List<WebElement> notifications = driver.findElements(By.xpath(".//*[@id='headerBar']/a"));
		
		for (WebElement notification : notifications) {
			 String notificationHeader =  notification.getText();
			 if(notificationHeader.contains("Wiper"))
			 {
				 isWiperReplaceNotificationPresent = true;
			 }
		}
		
		
		
		if(!isWiperReplaceNotificationPresent)
		{
			driver.findElement(By.cssSelector("a[href='/Device/MaintenanceManagement/"+sensorId+"']")).click();
			driver.findElement(By.xpath("html/body/div[2]/div[2]/div[2]/span")).click();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[starts-with(@href, '/SolitaxMaintenance/Index')]")));
			CommonFunctions.takeSnap(driver, "./two.jpg");
		}
		deviceListPage.clickMaitenanceNotificationBanner(identifier);
	}*/
}

