package testNG_Assignment;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.*;

public class AdvanceSearchBug {
	private WebDriver wd;
	private Properties p;
  @Parameters(value={"config_file"} )
  @Test
  public void AdvanceSearchBugUsingAdavanceOptions(String searchProperyFile) {
	  p=new Properties();
	  try {
		FileInputStream fis=new FileInputStream(searchProperyFile);
		p.load(fis);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	wd.findElement(By.linkText("Search")).click();
	wd.findElement(By.linkText("Advanced Search")).click();
	String summary,product,component,version,severity,priority,reporter;
	summary=p.getProperty("Summary");
	product=p.getProperty("Product");
	component=p.getProperty("Component");
	version=p.getProperty("Version");
	severity=p.getProperty("Severity");
	priority=p.getProperty("Priority");
	reporter=p.getProperty("Reporter");
	System.out.println("Property retrieved values are: Summary: "+summary+"\n Product: "+product+"\n Component: "+component+"\n Version: "+version+"\n Severity: "+severity+"\n Priority: "+priority+"\n Reporter: "+reporter);
	wd.findElement(By.id("short_desc")).sendKeys(summary);
	wd.findElement(By.id("product")).sendKeys(product);
	wd.findElement(By.id("component")).sendKeys(component);
	wd.findElement(By.id("version")).sendKeys(version);
	wd.findElement(By.id("bug_severity")).sendKeys(severity);
	wd.findElement(By.id("priority")).sendKeys(priority);
	wd.findElement(By.name("email2")).sendKeys(reporter);
	wd.findElement(By.id("Search")).click();
	wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	if (isSearchCriteriaAsPerSelection(summary,product,component,version,severity,priority,reporter)) {
		int bugCount=wd.findElements(By.xpath("//div[@id=\"bugzilla-body\"]/table/tbody/tr")).size();
		System.out.println("Total bug count is : "+bugCount);
		Reporter.log("For the  "+summary+" - "+bugCount+" bugs are found with Priority as "+priority+" and  severity as "+severity);
		
	} else {
			System.out.println("Wrong selection Criteria is displayed. Please check selected criteria and search againt.....");
	}
	

	
	

  }
  private boolean isSearchCriteriaAsPerSelection(String summary, String product,
		String component, String version, String severity, String priority,
		String reporter) {
	// TODO Auto-generated method stub
	  String priorityText,severityText,versionText,componentText,productText,reporterText,summaryText;
	  priorityText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[1]")).getText();
	  severityText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[2]")).getText();
	  versionText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[4]")).getText();
	  componentText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[5]")).getText();
	  productText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[6]")).getText();
	  reporterText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[8]")).getText();
	  summaryText=wd.findElement(By.xpath("//div[@id=\"bugzilla-body\"]/ul/li[10]")).getText();
	  
	  if (priorityText.contains(priority)&&severityText.contains(severity)&&versionText.contains(version)&&componentText.contains(component)&&productText.contains(product)&&reporterText.contains(reporter)&&summaryText.contains(summary)) {
		return true;
	} else {
		return false;
	}
	
}
@BeforeTest
  public void beforeTest() {
	  wd=new FirefoxDriver();
		wd.get("https://hjbugzilla.persistent.co.in/ELTP2011/?GoAheadAndLogIn=1");
		wd.manage().window().maximize();
		wd.findElement(By.id("Bugzilla_login")).sendKeys("tester001@persistent.co.in");
		wd.findElement(By.id("Bugzilla_password")).sendKeys("tester001");
		wd.findElement(By.id("log_in")).click();
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		if (wd.getTitle().equals("Bugzilla Main Page")) {
			  System.out.println("Login to Bugzilla is successful!!!!");
			
		} else {
				System.out.println("BugZill Main page is not displayed. please check");
				wd.quit();
		}
  }

  @AfterTest
  public void afterTest() {
	  wd.findElement(By.linkText("Log out")).click();
	  wd.quit();
  }

}
