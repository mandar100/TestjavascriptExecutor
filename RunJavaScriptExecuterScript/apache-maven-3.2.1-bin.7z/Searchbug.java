package testNG_Assignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Reporter;
import org.testng.annotations.*;




public class Searchbug {
	private WebDriver wd;
	private Properties p;
	@Parameters(value={"config_file"} )	
  @Test
  public void Searchbug_Using_SearchTerm(String searchProperyFile)
  {
	  p=new Properties();
	  try {
		FileInputStream fis=new FileInputStream(searchProperyFile);
		p.load(fis);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	wd.findElement(By.linkText("Search")).click();
	if(!wd.getTitle().equals("Find a Specific Bug"))
	{
		wd.findElement(By.linkText("Find a Specific Bug")).click();
	}
	String searchTermForSpecificBug=p.getProperty("searchTerm");
	System.out.println("Search for term= "+searchTermForSpecificBug);
	wd.findElement(By.id("content")).sendKeys(searchTermForSpecificBug);
	wd.findElement(By.id("search")).click();
	int bugCount=wd.findElements(By.xpath("//div[@id=\"bugzilla-body\"]/table/tbody/tr")).size();
	System.out.println("Total bug count is : "+bugCount);
	Reporter.log("For the  "+searchTermForSpecificBug+" - "+bugCount+" bugs are found.");
	
  }
  
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }
 
  @BeforeTest
  public void beforeTest() {
	  wd=new FirefoxDriver();
		wd.get("https://hjbugzilla.persistent.co.in/ELTP2011/?GoAheadAndLogIn=1");
		wd.manage().window().maximize();
		wd.findElement(By.id("Bugzilla_login")).sendKeys("tester001@persistent.co.in");
		wd.findElement(By.id("Bugzilla_password")).sendKeys("tester001");
		wd.findElement(By.id("log_in")).click();
		wd.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		if (wd.getTitle().equals("Bugzilla Main Page")) {
			  System.out.println("Login to Bugzilla is successful!!!!");
			
		} else {
				System.out.println("BugZill Main page is not displayed. please check");
				wd.quit();
		}
  }

  @AfterTest
  public void afterTest() {
	  wd.findElement(By.linkText("Log out")).click();
	  wd.quit();
  }

}
