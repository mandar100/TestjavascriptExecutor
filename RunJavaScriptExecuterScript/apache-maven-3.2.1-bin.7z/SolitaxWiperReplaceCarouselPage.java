package automation.framework.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;

/**
 * @author Nilesh_Dharmadhikari
 *
 */
public class SolitaxWiperReplaceCarouselPage {

	WebDriver driver;
	public SolitaxWiperReplaceCarouselPage()
	{
		driver = BrowserHelper.driver;
	}
	public void verifyCarouselPageForSolitaxWiperReplace(String sensorId){
		String url = driver.getCurrentUrl();
		WebDriverWait wait = new WebDriverWait(driver,30);
		String[] slide1 = {"soft, wet cloth","new wiper blade","hex wrench (M4)"};
		List<String> ls = new ArrayList();
		for(int i=0;i<slide1.length;i++){
			ls.add(slide1[i]);
		}
		Assert.assertEquals(url.contains("ManualCleanStartAsync"),true,"comparing URLs");
		List<String> list = new ArrayList();
		int size = driver.findElements(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/ul/li")).size();
		
		for(int i=1;i<=size;i++){
			System.out.println(driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/ul/li["+i+"]")).getText());
			list.add(driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[1]/div/div[2]/ul/li["+i+"]")).getText());
		}
		Assert.assertEquals(list,ls,"comparing slide1");
		String expSlide2 = "Make sure that the sensor is connected and the power is on.";
		String actSlide2 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[2]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide2,actSlide2,"comparing slide2");
		String expSlide3 = "Remove the sensor from the process. Clean the exterior of the sensor with a soft, wet cloth.";
		String actSlide3 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[3]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide3,actSlide3,"comparing slide3");
		driver.findElement(By.xpath(".//*[@id='mycarousel']/ul/li[4]/button")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[id='continueButton']")));
		String expSlide4 = "Loosen the screw to uninstall the wiper arm.";
		String actSlide4 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[4]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide4,actSlide4,"comparing slide4");
		String expSlide5 = "Replace the wiper blade.";
		String actSlide5 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[5]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide5,actSlide5,"comparing slide5");
		String expSlide6 = "Install the wiper arm.";
		String actSlide6 = driver.findElement(By.xpath(".//*[@id='mycarousel']/div/div/div[6]/div/div/div[2]")).getText();
		Assert.assertEquals(expSlide6,actSlide6,"comparing slide6");
		boolean backChevron = driver.findElement(By.xpath(".//*[@id='navBar']/div/a/div")).isEnabled();
		Assert.assertEquals(backChevron,true,"Checking back chevron");
		boolean continueBtn = driver.findElement(By.cssSelector("button[id='continueButton']")).isEnabled();
		Assert.assertEquals(continueBtn,true,"Checking Continue button");
		boolean cancelBtn = driver.findElement(By.cssSelector("button[id='cancelButton']")).isEnabled();
		Assert.assertEquals(cancelBtn,true,"Checking Cancel button");
		driver.findElement(By.cssSelector("button[id='continueButton']")).click();
	}
}
