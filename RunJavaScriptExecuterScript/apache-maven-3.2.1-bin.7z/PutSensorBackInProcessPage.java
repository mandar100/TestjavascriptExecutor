/**
 * 
 */
package automation.framework.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;

/**
 * @author Shubhangi_Pote
 *
 */
public class PutSensorBackInProcessPage {
	
	WebDriver driver;
	By popup = By.xpath(".//*[@id='putInProcessModal']/div/div/div[1]");
	By popupHeaderText = By.xpath(".//*[@id='putInProcessModal']/div/div/div[1]/div/div[1]");
	By holdExpires = By.xpath(".//*[@id='holdExpiresSettingId']/div/a/div");
	By oneMinHoldRadioBtn = By.xpath(".//*[@id='holdExpiresSettingId']/div/div/div/div/div/button[1]");
	By fiveMinHoldRadioBtn = By.xpath(".//*[@id='holdExpiresSettingId']/div/div/div/div/div/button[2]");
	By tenMinHoldRadioBtn = By.xpath(".//*[@id='holdExpiresSettingId']/div/div/div/div/div/button[3]");
	By selectedHoldValueNumber = By.xpath(".//*[@id='holdExpiresSettingId']/div/div/a/span[1]");
	By selectedHoldValueText = By.xpath(".//*[@id='holdExpiresSettingId']/div/div/a/span[2]");
		
	private String expectedHeaderText = "Put the sensor back into the process";
	private String expectedHoldExpiresText ="Hold expires in";
	private String expectedSuccessPageTitle ="Done! - Fusion";
	private String expectedBackgroundColorBlue ="#0098db";
	private String expectedBackgroundColorWhite ="#fff";
	private String expectedOneMinHoldValueNumber ="1";
	private String expectedFiveMinHoldValueNumber ="5";
	private String expectedTenMinHoldValueNumber ="10";
	private String expectedMinuteText ="Minute";
	private String expectedMinutesText ="Minutes";
	
	private String mismatchingHeaderText = "Mismatching header text" ;
	private String mismatchingHoldExpiresText = "Mismatching hold expires text" ;
	private String mismatchingSuccessPageTitle = "Mismatching success page title. User is not navigated to success page";
	private String oneMinOptionNotSelected ="One min option has not been selected";
	private String oneMinOptionSelected = "One min option also got selected along with other options";
	private String fiveMinOptionNotSelected ="Five min option has not been selected";
	private String fiveMinOptionSelected = "Five min option also got selected along with other options";
	private String tenMinOptionNotSelected ="Ten min option has not been selected";
	private String tenMinOptionSelected = "Ten min option also got selected along with other options";
	private String mismatchingHoldExpiresSelectedValue = "Mismatching selected hold expires value";
	private String missingHoldExpiresPanel = "Hold expires panel does not exists on put senor back page";
		
	
	/** Constructor for PutSensorBackInProcessPage
	 * @param driver
	 */
	public PutSensorBackInProcessPage()
	{
		this.driver = BrowserHelper.driver;
	}
	
	private void checkSelectedHoldExpireValue(String selectedHoldNumber, String selectedHoldText){
		
		String actualHoldValueNumber = driver.findElement(selectedHoldValueNumber).getText();		
		String actualHoldValueText = driver.findElement(selectedHoldValueText).getText();
		Assert.assertEquals(actualHoldValueNumber.concat(" ").concat(actualHoldValueText),
				selectedHoldNumber.concat(" ").concat(selectedHoldText),mismatchingHoldExpiresSelectedValue);			
	}
	
	/**
	 * Verifies popup header text 
	 */
	public void checkPopupHeader(){		
		String actualHeaderText = driver.findElement(popupHeaderText).getText();
		Assert.assertEquals(actualHeaderText,expectedHeaderText,mismatchingHeaderText);		
	}
	
	/**
	 *  Verifies that hold expires in popup appears if Hold is selected on page 1
	 */
	public void checkHoldExpiresPanelAppears(){
		
		if(CommonFunctions.isHoldSetForWorkflow)
		{
			boolean isHoldExpiresPanelExists = (driver.findElements(holdExpires).size()==1);			
			Assert.assertTrue(isHoldExpiresPanelExists,missingHoldExpiresPanel);
			
			String actualHoldExpiresText = driver.findElement(holdExpires).getText();
			Assert.assertEquals(actualHoldExpiresText,expectedHoldExpiresText,mismatchingHoldExpiresText);
		}		
	}
	
	/**
	 * Verifies select for 1 min options
	 */
	public void SelectOneMin(){
		driver.findElement(oneMinHoldRadioBtn).click();
		String oneMinBtnBackgroundColor = driver.findElement(oneMinHoldRadioBtn).getCssValue("background-color").toString();
		String fiveMinBtnBackgroundColor = driver.findElement(fiveMinHoldRadioBtn).getCssValue("background-color").toString();
		String tenMinBtnBackgroundColor = driver.findElement(tenMinHoldRadioBtn).getCssValue("background-color").toString();
		
		Assert.assertEquals(oneMinBtnBackgroundColor,expectedBackgroundColorBlue,oneMinOptionNotSelected);
		Assert.assertEquals(fiveMinBtnBackgroundColor, expectedBackgroundColorWhite, fiveMinOptionSelected);
		Assert.assertEquals(tenMinBtnBackgroundColor, expectedBackgroundColorWhite, tenMinOptionSelected);
		
		driver.findElement(holdExpires).click();
		checkSelectedHoldExpireValue(expectedOneMinHoldValueNumber,expectedMinuteText);	
	}
	
	/**
	 * Verifies select for 5 mins options
	 */
	public void SelectFiveMin(){
		driver.findElement(fiveMinHoldRadioBtn).click();
		
		String oneMinBtnBackgroundColor = driver.findElement(oneMinHoldRadioBtn).getCssValue("background-color").toString();
		String fiveMinBtnBackgroundColor = driver.findElement(fiveMinHoldRadioBtn).getCssValue("background-color").toString();
		String tenMinBtnBackgroundColor = driver.findElement(tenMinHoldRadioBtn).getCssValue("background-color").toString();
		
		Assert.assertEquals(fiveMinBtnBackgroundColor, expectedBackgroundColorBlue, fiveMinOptionNotSelected);
		Assert.assertEquals(oneMinBtnBackgroundColor,expectedBackgroundColorWhite,oneMinOptionSelected);		
		Assert.assertEquals(tenMinBtnBackgroundColor, expectedBackgroundColorWhite, tenMinOptionSelected);
		
		driver.findElement(holdExpires).click();
		checkSelectedHoldExpireValue(expectedFiveMinHoldValueNumber,expectedMinutesText);
	}

	/**
	 * Verifies select for 10 mins options
	 */
	public void SelectTenMin(){
		driver.findElement(tenMinHoldRadioBtn).click();
		
		String oneMinBtnBackgroundColor = driver.findElement(oneMinHoldRadioBtn).getCssValue("background-color").toString();
		String fiveMinBtnBackgroundColor = driver.findElement(fiveMinHoldRadioBtn).getCssValue("background-color").toString();
		String tenMinBtnBackgroundColor = driver.findElement(tenMinHoldRadioBtn).getCssValue("background-color").toString();
		
		Assert.assertEquals(tenMinBtnBackgroundColor, expectedBackgroundColorBlue, tenMinOptionNotSelected);
		Assert.assertEquals(oneMinBtnBackgroundColor,expectedBackgroundColorWhite,oneMinOptionSelected);
		Assert.assertEquals(fiveMinBtnBackgroundColor, expectedBackgroundColorWhite, fiveMinOptionSelected);
		
		driver.findElement(holdExpires).click();
		checkSelectedHoldExpireValue(expectedTenMinHoldValueNumber,expectedMinutesText);
	}
	
	/**
	 * Verifies that user navigates to success page on click on done button
	 */
	public void clickOnDoneButton(){
		driver.findElement(By.cssSelector("button[id='donePuttingBackInProcess']")).click();
		String actualPageTitle = BrowserHelper.getTitleOfPage();
		Assert.assertEquals(actualPageTitle,expectedSuccessPageTitle,mismatchingSuccessPageTitle);
	}
}
