package automation.framework.pages;

public class AmtaxFlowPages {
	
	public void navigateToAmtaxDeviceDetailsPage(){
		//Select device on device list page
	}
	
	public void startAmtaxElectrolyteMembraneReplacementFlow(){
		
	}
}
