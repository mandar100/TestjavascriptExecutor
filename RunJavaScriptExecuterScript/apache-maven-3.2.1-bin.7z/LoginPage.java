package automation.framework.pages;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import automation.commonfunctions.BrowserHelper;
import automation.commonfunctions.CommonFunctions;
import automation.commonfunctions.LoginDetailsRecord;


/**
 * @author Shubhangi_Pote
 *
 */
public class LoginPage {
	WebDriver fusionDriver;
	
	public LoginPage() {
		this.fusionDriver=BrowserHelper.driver;
		PageFactory.initElements(fusionDriver,this);
	}
		
	@FindBy(id="Email")
	private WebElement tenantUsernameInput;
	@FindBy(id="Password")
	private WebElement tenantPasswordInput;
	@FindBy(xpath=".//input[@value='Log in']")
	private WebElement logInButton;
	String tenantUserName, tenantPassword, solitaxSensorId;
	
	protected String getTenantUserName() {
		return tenantUserName;
	}

	protected void setTenantUserName(String tenantUserName) {
		this.tenantUserName = tenantUserName;
	}

	protected String getTenantPassword() {
		return tenantPassword;
	}

	protected void setTenantPassword(String tenantPassword) {
		this.tenantPassword = tenantPassword;
	}

	protected String getSolitaxSensorId() {
		return solitaxSensorId;
	}

	protected void setSolitaxSensorId(String solitaxSensorId) {
		this.solitaxSensorId = solitaxSensorId;
	}
	
	/*
	 * Method - readCredentials
	 * Desc - reads credentials for given user
	 * Parameter - hachLoginInfoData , userRole
	 * */
	public void readCredentials(String hachLoginInfoData, String userRole){
		Map<String, LoginDetailsRecord> loginData=CommonFunctions.readHachDataFile(hachLoginInfoData);
		setTenantUserName(loginData.get(userRole).getUserName());
		setTenantPassword(loginData.get(userRole).getPassword());
	}
	
	public void loginToApplication()
	{
		//String app_url = "http://fusionqaautomation.cloudapp.net/";
		//String app_url = "http://app2playground.cloudapp.net/";
		fusionDriver.get(CommonFunctions.app_url);
		//CommonFunctions.loginToApplication(url, u_name, password)
		File currentDirFile = new File(".");	
		String dir = currentDirFile.getAbsolutePath().replace(".", "TestData\\LoginDetails.xlsx");		
		readCredentials(dir,"HSA_User");		
		tenantUsernameInput.sendKeys(getTenantUserName());
		tenantPasswordInput.sendKeys(getTenantPassword());
		logInButton.click();		
	}
		
	public void forgotPassword(){		
		/* Good to have */
	}
	
	public void privacyPolicy(){		
		/* Good to have */
	}
	
}
